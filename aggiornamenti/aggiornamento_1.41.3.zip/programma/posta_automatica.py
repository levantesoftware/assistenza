# -*- coding: utf-8 -*-
"""
Assistenza impianti - RICEZIONE AUTOMATICA DELLA POSTA DEI TECNICI (parte del servizio per l'ufficio)

Il tecnico invia l'intervento (file dati + PDF, oppure uno zip) all'indirizzo dell'ufficio. Questo modulo porta quei file
nella cartella  C:\\Assistenza\\posta\\arrivo ; l'app dell'ufficio li vede da sola, li importa in "Posta in arrivo" e li sposta
in  C:\\Assistenza\\posta\\importati.

Come i file arrivano nella cartella di arrivo (si sceglie dall'app, ogni cliente usa quello che ha):
  - "cartella"  : si guarda una cartella del PC (per esempio Download, o dove una regola di Outlook/Thunderbird salva gli
                  allegati) e si copiano i file dei tecnici. Funziona con QUALSIASI programma di posta.
  - "imap"      : il programma legge la casella di posta (Gmail, Aruba, hosting, PEC...) con nome utente e password.
                  Si leggono solo i messaggi con una certa parola nell'oggetto; i messaggi non si toccano, non si cancellano
                  e non risultano letti.
  - "outlook"   : legge Outlook (versione classica per Windows) gia' aperto sul PC, senza password.
  - "nessuno"   : niente di automatico; i file si scelgono a mano da "Posta in arrivo".

La password della posta, se serve, e' salvata sul PC protetta con l'account Windows (non leggibile in chiaro da un altro utente).
Non viene mai mandata fuori da questo PC.
"""
import base64
import datetime
import email
import email.header
import email.policy
import email.utils
import email.message
import imaplib
import json
import os
import re
import shutil
import smtplib
import ssl
import subprocess
import tempfile
import threading
import time
import zipfile

ESTENSIONI = (".zip", ".txt", ".json", ".pdf")
MESI = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
PREDEFINITI = {
    "metodo": "nessuno",          # nessuno | cartella | imap | outlook
    "minuti": 3,
    "filtro": "Intervento",       # parola che deve esserci nell'oggetto della mail O nel nome del file allegato (vuoto = tutte le mail con allegati).
                                  # Si possono scrivere piu' parole separate da «;». Se c'e' «Intervento» vale anche «Cantiere».
    "giorni": 14,                 # quanto indietro guardare nella posta
    "cartella_osservata": "",
    "archivia_registrati": True,  # cartella osservata: quando l'intervento e' registrato in Levante, i file originali vanno nella sottocartella "Registrati"
    "smtp_server": "", "smtp_porta": 465, "smtp_sicurezza": "ssl", "smtp_utente": "", "smtp_password": "", "smtp_da": "", "invio_metodo": "smtp",   # invio dei pacchetti ai tecnici
    "imap_server": "", "imap_porta": 993, "imap_ssl": True, "imap_utente": "", "imap_password": "", "imap_cartella": "INBOX",
}


# ---------------------------------------------------------------- protezione della password
def proteggi(testo):
    if not testo:
        return ""
    dati = testo.encode("utf-8")
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            class BLOB(ctypes.Structure):
                _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
            b_in = BLOB(len(dati), ctypes.cast(ctypes.create_string_buffer(dati, len(dati)), ctypes.POINTER(ctypes.c_char)))
            b_out = BLOB()
            if ctypes.windll.crypt32.CryptProtectData(ctypes.byref(b_in), "Assistenza", None, None, None, 0, ctypes.byref(b_out)):
                r = ctypes.string_at(b_out.pbData, b_out.cbData)
                ctypes.windll.kernel32.LocalFree(b_out.pbData)
                return "dpapi:" + base64.b64encode(r).decode("ascii")
        except Exception:
            pass
    return "b64:" + base64.b64encode(dati).decode("ascii")


def svela(testo):
    if not testo:
        return ""
    try:
        if testo.startswith("dpapi:") and os.name == "nt":
            import ctypes
            from ctypes import wintypes

            class BLOB(ctypes.Structure):
                _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
            dati = base64.b64decode(testo[6:])
            b_in = BLOB(len(dati), ctypes.cast(ctypes.create_string_buffer(dati, len(dati)), ctypes.POINTER(ctypes.c_char)))
            b_out = BLOB()
            if ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(b_in), None, None, None, None, 0, ctypes.byref(b_out)):
                r = ctypes.string_at(b_out.pbData, b_out.cbData)
                ctypes.windll.kernel32.LocalFree(b_out.pbData)
                return r.decode("utf-8")
            return ""
        if testo.startswith("b64:"):
            return base64.b64decode(testo[4:]).decode("utf-8")
    except Exception:
        return ""
    return ""


def nome_sicuro(nome):
    nome = os.path.basename(str(nome).replace("\\", "/")).strip() or "file"
    nome = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", nome)
    return nome[:150]


def decodifica(valore):
    try:
        return str(email.header.make_header(email.header.decode_header(valore or "")))
    except Exception:
        return str(valore or "")


MAGIC_CIFRATO = b"ASSENC1\x00"


def e_protetto(percorso):
    """File cifrato dall'app col codice di sicurezza: il contenuto non si legge qui, lo apre l'app."""
    try:
        with open(percorso, "rb") as f:
            return f.read(8) == MAGIC_CIFRATO
    except Exception:
        return False


def testo_di_intervento(percorso):
    """Un .txt/.json che e' un intervento (o un cantiere) dei tecnici anche se il nome e' stato cambiato (WhatsApp, mail, rinominato a mano)."""
    if e_protetto(percorso):
        return True
    try:
        with open(percorso, "rb") as f:
            testa = f.read(65536).decode("utf-8", "ignore")
        return re.search(r'"assist"\s*:\s*"(intervento|cantiere)"', testa) is not None
    except Exception:
        return False


def parole_filtro(valore):
    """«Intervento» (o altre parole separate da ; , |) -> elenco in minuscolo. Con «Intervento» vale anche «Cantiere»: i rapportini dei cantieri sono mail come gli altri."""
    lista = [x.strip().lower() for x in re.split(r"[;,|]", str(valore or "")) if x.strip()]
    if "intervento" in lista and "cantiere" not in lista:
        lista.append("cantiere")
    return lista


def zip_di_intervento(percorso):
    """Uno zip con dentro un intervento: o un Dati_*.txt, o un qualunque .txt/.json che ne abbia il contenuto (nomi cambiati)."""
    if e_protetto(percorso):
        return True
    try:
        with zipfile.ZipFile(percorso) as z:
            for info in z.infolist():
                if "__MACOSX/" in info.filename or info.filename.replace("\\", "/").split("/")[-1].startswith("."):
                    continue                      # file di servizio dei Mac (._nome, .DS_Store)
                n = info.filename.replace("\\", "/").split("/")[-1]
                if re.match(r"^Dati_.*\.(txt|json)$", n, re.I):
                    return True
                if n.lower().endswith((".txt", ".json")) and 0 < info.file_size < 30 * 1024 * 1024:
                    with z.open(info) as f:
                        if re.search(r'"assist"\s*:\s*"(intervento|cantiere)"', f.read(65536).decode("utf-8", "ignore")):
                            return True
    except Exception:
        pass
    return False


# ---------------------------------------------------------------- il gestore
class Posta:
    def __init__(self, radice):
        self.dir = os.path.join(radice, "posta")
        self.arrivo = os.path.join(self.dir, "arrivo")
        self.importati = os.path.join(self.dir, "importati")
        self.conf_path = os.path.join(self.dir, "config.json")
        self.visti_path = os.path.join(self.dir, "visti.json")
        self.origini_path = os.path.join(self.dir, "origini.json")      # nome in "arrivo" -> [percorso originale, cartella osservata]
        self._origini = None
        self.allegati = os.path.join(radice, "allegati")                 # PDF dei rapporti: restano qui, da trascinare in Levante
        for d in (self.arrivo, self.importati, self.allegati):
            os.makedirs(d, exist_ok=True)
        self.blocco = threading.Lock()
        self.run = {"in_corso": False, "ultimo": "", "esito": "", "nuovi": 0}
        self.subito = threading.Event()
        self._visti = None

    # ---- configurazione
    def config(self):
        c = dict(PREDEFINITI)
        try:
            with open(self.conf_path, encoding="utf-8") as f:
                c.update(json.load(f))
        except Exception:
            pass
        return c

    def config_pubblica(self):
        c = self.config()
        c["password_impostata"] = bool(c.get("imap_password"))
        c["imap_password"] = ""
        c["smtp_password_impostata"] = bool(c.get("smtp_password"))
        if c.get("invio_metodo") == "outlook":
            c["smtp_pronto"] = os.name == "nt"
        else:
            c["smtp_pronto"] = bool(c.get("smtp_server") and c.get("smtp_password") and (c.get("smtp_utente") or c.get("smtp_da")))
        c["smtp_password"] = ""
        return c

    def salva_config(self, nuova):
        c = self.config()
        for k in PREDEFINITI:
            if k in ("imap_password", "smtp_password") or k not in nuova:
                continue
            v = nuova[k]
            if k in ("minuti", "giorni", "imap_porta", "smtp_porta"):
                try:
                    v = max(1, int(v))
                except Exception:
                    v = PREDEFINITI[k]
            if k in ("imap_ssl", "archivia_registrati"):
                v = bool(v)
            c[k] = v.strip() if isinstance(v, str) else v
        if c["metodo"] not in ("nessuno", "cartella", "imap", "outlook"):
            c["metodo"] = "nessuno"
        if c.get("invio_metodo") not in ("smtp", "outlook"):
            c["invio_metodo"] = "smtp"
        if c.get("smtp_sicurezza") not in ("ssl", "starttls"):
            c["smtp_sicurezza"] = "ssl"
        if nuova.get("smtp_password"):
            c["smtp_password"] = proteggi(nuova["smtp_password"])
        if nuova.get("togli_password"):
            c["imap_password"] = ""
        elif nuova.get("imap_password"):
            c["imap_password"] = proteggi(nuova["imap_password"])
        with open(self.conf_path, "w", encoding="utf-8") as f:
            json.dump(c, f, indent=1, ensure_ascii=False)
        self.subito.set()

    # ---- invio di mail (pacchetti ai tecnici) via SMTP
    def _smtp_connetti(self, c):
        if not c.get("smtp_server"):
            raise RuntimeError("Manca il server di posta in uscita (SMTP).")
        pwd = svela(c.get("smtp_password", ""))
        if not pwd:
            raise RuntimeError("Manca la password della posta in uscita.")
        porta = int(c.get("smtp_porta") or 465)
        if c.get("smtp_sicurezza") == "starttls":
            srv = smtplib.SMTP(c["smtp_server"], porta, timeout=30)
            srv.ehlo()
            srv.starttls(context=ssl.create_default_context())
            srv.ehlo()
        else:
            srv = smtplib.SMTP_SSL(c["smtp_server"], porta, timeout=30, context=ssl.create_default_context())
        try:
            srv.login(c.get("smtp_utente") or c.get("smtp_da"), pwd)
        except Exception:
            try:
                srv.quit()
            except Exception:
                pass
            raise
        return srv

    # ---- invio tramite Outlook classico (Windows): niente password, usa l'account gia' configurato in Outlook
    def _outlook_script(self):
        return r"""
$ErrorActionPreference = 'Stop'
try { $ol = New-Object -ComObject Outlook.Application } catch { Write-Output 'ERRORE|Non riesco ad aprire Outlook. Serve Outlook classico per Windows (non il nuovo Outlook).'; exit 0 }
if ($env:ASS_PROVA -eq '1') { Write-Output 'OK|prova'; exit 0 }
try {
  $j = Get-Content -LiteralPath $env:ASS_JSON -Raw -Encoding UTF8 | ConvertFrom-Json
  $m = $ol.CreateItem(0)
  $m.To = ($j.a -join ';')
  $m.Subject = [string]$j.oggetto
  $m.Body = [string]$j.testo
  foreach ($f in $j.file) { [void]$m.Attachments.Add([string]$f) }
  $m.Send()
  Write-Output 'OK|inviata'
} catch { Write-Output ('ERRORE|' + $_.Exception.Message) }
"""

    def _outlook_esegui(self, prova, dati=None, allegati=None):
        if os.name != "nt":
            return {"ok": False, "messaggio": "L'invio tramite Outlook funziona solo da Windows."}
        tmpdir = tempfile.mkdtemp(prefix="ass_ol_", dir=self.dir)
        try:
            ps = os.path.join(tmpdir, "invia.ps1")
            with open(ps, "w", encoding="utf-8-sig") as f:
                f.write(self._outlook_script())
            env = dict(os.environ, ASS_PROVA="1" if prova else "0")
            if not prova:
                files = []
                for al in allegati or []:
                    pf = os.path.join(tmpdir, nome_sicuro(al.get("nome", "file")))
                    with open(pf, "wb") as f:
                        f.write(al["dati"])
                    files.append(pf)
                dati = dict(dati, file=files)
                jp = os.path.join(tmpdir, "mail.json")
                with open(jp, "w", encoding="utf-8") as f:
                    json.dump(dati, f, ensure_ascii=False)
                env["ASS_JSON"] = jp
            try:
                r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", ps], env=env,
                                   capture_output=True, timeout=150, creationflags=0x08000000, stdin=subprocess.DEVNULL)
            except subprocess.TimeoutExpired:
                return {"ok": False, "messaggio": "Outlook non ha risposto in tempo (forse aspetta una conferma sullo schermo)."}
            testo = r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")
            for riga in testo.splitlines():
                riga = riga.strip()
                if riga.startswith("ERRORE|"):
                    return {"ok": False, "messaggio": riga[7:][:300]}
                if riga.startswith("OK|"):
                    return {"ok": True, "messaggio": "Outlook risponde: si possono inviare mail." if prova else "inviata"}
            return {"ok": False, "messaggio": "Outlook non ha risposto come previsto: " + testo.strip()[:200]}
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def prova_smtp(self):
        if self.config().get("invio_metodo") == "outlook":
            return self._outlook_esegui(True)
        try:
            srv = self._smtp_connetti(self.config())
            srv.quit()
            return {"ok": True, "messaggio": "Collegamento riuscito: si possono inviare mail."}
        except smtplib.SMTPAuthenticationError:
            return {"ok": False, "messaggio": "Utente o password non accettati dal server (con Gmail serve una «password per le app»)."}
        except Exception as e:
            return {"ok": False, "messaggio": "Non riesco a collegarmi: %s" % (str(e) or e.__class__.__name__)}

    def invia_mail(self, a, oggetto, testo, allegati):
        c = self.config()
        da = c.get("smtp_da") or c.get("smtp_utente")
        a = [x.strip() for x in re.split(r"[;,\s]+", a or "") if x.strip()]
        if not a or not all(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", x) for x in a):
            return {"ok": False, "messaggio": "Indirizzo email del destinatario non valido."}
        if c.get("invio_metodo") == "outlook":
            lista = []
            for al in allegati or []:
                try:
                    lista.append({"nome": al.get("nome", "file"), "dati": base64.b64decode(al.get("b64", ""))})
                except Exception:
                    return {"ok": False, "messaggio": "Allegato non valido."}
            r = self._outlook_esegui(False, {"a": a, "oggetto": (oggetto or "Appuntamenti").replace("\r", " ").replace("\n", " ")[:200], "testo": testo or ""}, lista)
            if r["ok"]:
                r["messaggio"] = "Mail inviata a %s (tramite Outlook)." % ", ".join(a)
            return r
        m = email.message.EmailMessage()
        m["From"] = da
        m["To"] = ", ".join(a)
        m["Subject"] = (oggetto or "Appuntamenti").replace("\r", " ").replace("\n", " ")[:200]
        m["Date"] = email.utils.formatdate(localtime=True)
        m["Message-ID"] = email.utils.make_msgid()
        m.set_content(testo or "")
        for al in allegati or []:
            try:
                dati = base64.b64decode(al.get("b64", ""))
            except Exception:
                return {"ok": False, "messaggio": "Allegato non valido."}
            tipo, _, sub = (al.get("tipo") or "application/octet-stream").partition("/")
            m.add_attachment(dati, maintype=tipo or "application", subtype=sub or "octet-stream", filename=nome_sicuro(al.get("nome", "file")))
        try:
            srv = self._smtp_connetti(c)
            try:
                srv.send_message(m)
            finally:
                try:
                    srv.quit()
                except Exception:
                    pass
        except smtplib.SMTPAuthenticationError:
            return {"ok": False, "messaggio": "Utente o password non accettati dal server."}
        except Exception as e:
            return {"ok": False, "messaggio": "Invio non riuscito: %s" % (str(e) or e.__class__.__name__)}
        return {"ok": True, "messaggio": "Mail inviata a %s." % ", ".join(a)}

    # ---- messaggi gia' visti (per non scaricare due volte la stessa mail)
    def visti(self):
        if self._visti is None:
            try:
                with open(self.visti_path, encoding="utf-8") as f:
                    self._visti = list(json.load(f))
            except Exception:
                self._visti = []
        return self._visti

    def segna_visto(self, chiave):
        v = self.visti()
        if chiave not in v:
            v.append(chiave)
            del v[:-3000]
            try:
                with open(self.visti_path, "w", encoding="utf-8") as f:
                    json.dump(v, f)
            except Exception:
                pass

    def azzera_visti(self):
        """Dimentica le mail gia' lette: al prossimo controllo vengono riscaricate (quelle degli ultimi giorni)."""
        self._visti = []
        try:
            with open(self.visti_path, "w", encoding="utf-8") as f:
                json.dump([], f)
        except Exception:
            return False
        self.subito.set()
        return True

    # ---- archivio: i file originali degli interventi registrati vanno in <cartella osservata>\Registrati
    def origini(self):
        if self._origini is None:
            try:
                with open(self.origini_path, encoding="utf-8") as f:
                    self._origini = dict(json.load(f))
            except Exception:
                self._origini = {}
        return self._origini

    def segna_origine(self, nome_arrivo, percorso, radice):
        o = self.origini()
        o[nome_arrivo] = [percorso, radice]
        for k in list(o)[:-3000]:
            del o[k]
        try:
            with open(self.origini_path, "w", encoding="utf-8") as f:
                json.dump(o, f)
        except Exception:
            pass

    def archivia(self, nomi):
        """Sposta gli originali (non li cancella) in <cartella osservata>\\Registrati. Ritorna quanti ne ha spostati."""
        if not self.config().get("archivia_registrati", True):
            return {"ok": True, "spostati": 0, "archiviati": [str(n) for n in nomi or []], "messaggio": "archivio spento"}
        spostati, fatti = 0, []
        for nome in nomi or []:
            voce = self.origini().get(os.path.basename(str(nome)))
            if not voce:
                fatti.append(nome)               # arrivato per posta o caricato a mano: non c'e' niente da spostare
                continue
            orig, radice = voce
            if not os.path.isfile(orig):
                fatti.append(nome)               # gia' spostato o tolto a mano: non serve riprovare
                continue
            try:
                cart = os.path.join(radice, "Registrati")
                os.makedirs(cart, exist_ok=True)
                dest = os.path.join(cart, os.path.basename(orig))
                if os.path.exists(dest):
                    base, est = os.path.splitext(os.path.basename(orig))
                    dest = os.path.join(cart, "%s_%s%s" % (base, datetime.datetime.now().strftime("%H%M%S"), est))
                shutil.move(orig, dest)
                spostati += 1
                fatti.append(nome)
            except OSError:
                continue                         # file in uso o cartella protetta: riprova al prossimo giro
        return {"ok": True, "spostati": spostati, "archiviati": fatti}

    # ---- cartella di arrivo
    def salva_file(self, nome, dati):
        nome = nome_sicuro(nome)
        pre = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_")
        dest = os.path.join(self.arrivo, pre + nome)
        n = 1
        while os.path.exists(dest):
            n += 1
            dest = os.path.join(self.arrivo, "%s%d_%s" % (pre, n, nome))
        with open(dest + ".tmp", "wb") as f:
            f.write(dati)
        os.replace(dest + ".tmp", dest)
        return dest

    def elenco(self):
        out = []
        for n in sorted(os.listdir(self.arrivo)):
            p = os.path.join(self.arrivo, n)
            if os.path.isfile(p) and not n.endswith(".tmp"):
                out.append({"nome": n, "dimensione": os.path.getsize(p)})
        return out

    def leggi(self, nome):
        p = os.path.join(self.arrivo, os.path.basename(nome))
        if not os.path.isfile(p):
            return None
        with open(p, "rb") as f:
            return f.read()

    # ---- allegati dei rapporti (PDF) in una cartella fissa
    def salva_allegato(self, nome, dati):
        nome = nome_sicuro(nome)
        if not nome.lower().endswith(".pdf") or not dati:
            return False
        with open(os.path.join(self.allegati, nome), "wb") as f:
            f.write(dati)
        return True

    def recupera_allegati(self):
        """Mette in "allegati" anche i PDF dei rapporti gia' ricevuti (dentro gli zip di "arrivo" e "importati")."""
        for cart in (self.arrivo, self.importati):
            try:
                nomi = os.listdir(cart)
            except OSError:
                continue
            for n in nomi:
                if not n.lower().endswith(".zip"):
                    continue
                try:
                    with zipfile.ZipFile(os.path.join(cart, n)) as z:
                        for info in z.infolist():
                            base = nome_sicuro(info.filename)
                            if base.lower().endswith(".pdf") and not base.startswith(".") and not self.percorso_allegato(base) and info.file_size < 60 * 1024 * 1024:
                                self.salva_allegato(base, z.read(info))
                except Exception:
                    continue

    def percorso_allegato(self, nome):
        p = os.path.join(self.allegati, nome_sicuro(nome))
        return p if os.path.isfile(p) else None

    def elenco_allegati(self):
        try:
            return sorted(n for n in os.listdir(self.allegati) if n.lower().endswith(".pdf"))
        except OSError:
            return []

    def mostra_allegato(self, nome):
        p = self.percorso_allegato(nome)
        if not p or os.name != "nt":
            return False
        subprocess.Popen(["explorer", "/select," + os.path.normpath(p)], creationflags=0x08000000)
        return True

    def fatto(self, nome):
        nome = os.path.basename(nome)
        p = os.path.join(self.arrivo, nome)
        if not os.path.isfile(p):
            return False
        dest = os.path.join(self.importati, nome)
        if os.path.exists(dest):
            dest = os.path.join(self.importati, datetime.datetime.now().strftime("%H%M%S_") + nome)
        shutil.move(p, dest)
        return True

    # ---- 1) cartella osservata
    def da_cartella(self, c):
        """Una o piu' cartelle (separate da ';'), sottocartelle comprese (fino a 2 livelli: WhatsApp Desktop e i browser ne creano)."""
        cartelle = [x.strip().strip('"') for x in re.split(r"[;\n]", c.get("cartella_osservata") or "") if x.strip()]
        if not cartelle:
            raise RuntimeError("La cartella da controllare non e' stata scelta.")
        esistenti = [x for x in cartelle if os.path.isdir(x)]
        if not esistenti:
            raise RuntimeError("La cartella non esiste: %s" % cartelle[0])
        limite = time.time() - max(1, int(c.get("giorni", 14))) * 86400
        nuovi = 0
        self.diag = {"visti": 0, "vecchi": 0, "altri": 0}
        for cart in esistenti:
            file_ = []
            base = cart.rstrip("\\/").count(os.sep)
            for radice, sub, nomi in os.walk(cart):
                if radice.count(os.sep) - base >= 2:
                    sub[:] = []
                sub[:] = [d for d in sub if d.lower() != "registrati"]       # gli archiviati non si rileggono
                for n in nomi:
                    file_.append(os.path.join(radice, n))
            trovati, dati_tempi = [], []
            for p in file_:
                n = os.path.basename(p)
                try:
                    if not n.lower().endswith(ESTENSIONI) or n.lower().endswith(".pdf"):
                        continue
                    if os.path.getmtime(p) < limite:
                        self.diag["vecchi"] += 1
                        continue
                    if re.match(r"^Dati_.*\.(txt|json)$", n, re.I) or (n.lower().endswith(".zip") and zip_di_intervento(p)) \
                            or (n.lower().endswith((".txt", ".json")) and os.path.getsize(p) < 30 * 1024 * 1024 and testo_di_intervento(p)):
                        trovati.append(p)
                        dati_tempi.append(os.path.getmtime(p))
                    else:
                        self.diag["altri"] += 1
                except OSError:
                    continue
            for p in file_:      # i PDF che accompagnano un file dati (salvati negli stessi minuti)
                try:
                    if p.lower().endswith(".pdf") and os.path.getmtime(p) >= limite and any(abs(os.path.getmtime(p) - t) < 600 for t in dati_tempi):
                        trovati.append(p)
                except OSError:
                    continue
            for p in trovati:
                try:
                    chiave = "cartella|%s|%d|%d" % (p, os.path.getmtime(p), os.path.getsize(p))
                    if chiave in self.visti():
                        self.diag["visti"] += 1
                        continue
                    with open(p, "rb") as f:
                        dest = self.salva_file(os.path.basename(p), f.read())
                    self.segna_origine(os.path.basename(dest), p, cart)
                    self.segna_visto(chiave)
                    nuovi += 1
                except OSError:
                    continue
        return nuovi

    # ---- 2) IMAP
    def _imap_connetti(self, c):
        if not c["imap_server"] or not c["imap_utente"]:
            raise RuntimeError("Mancano il server o il nome utente della posta.")
        pwd = svela(c.get("imap_password", ""))
        if not pwd:
            raise RuntimeError("Manca la password della posta.")
        M = imaplib.IMAP4_SSL(c["imap_server"], int(c["imap_porta"]), timeout=40) if c.get("imap_ssl", True) else imaplib.IMAP4(c["imap_server"], int(c["imap_porta"]), timeout=40)
        try:
            M.login(c["imap_utente"], pwd)
        except imaplib.IMAP4.error as e:
            raise RuntimeError("La posta ha rifiutato nome utente o password (%s). Con Gmail serve una 'password per app'." % str(e)[:120])
        typ, _ = M.select('"%s"' % (c.get("imap_cartella") or "INBOX"), readonly=True)
        if typ != "OK":
            raise RuntimeError("Non trovo la cartella di posta '%s'." % c.get("imap_cartella"))
        return M

    def da_imap(self, c, solo_prova=False):
        M = self._imap_connetti(c)
        try:
            dal = datetime.date.today() - datetime.timedelta(days=max(1, int(c.get("giorni", 14))))
            typ, dati = M.search(None, "SINCE", "%02d-%s-%d" % (dal.day, MESI[dal.month - 1], dal.year))
            numeri = dati[0].split() if typ == "OK" and dati and dati[0] else []
            filtro = parole_filtro(c.get("filtro"))
            nuovi = trovate = 0
            self.diag = {"guardati": len(numeri), "gia": 0, "senza": 0}
            for num in numeri:
                typ, h = M.fetch(num, "(BODY.PEEK[HEADER.FIELDS (SUBJECT MESSAGE-ID DATE)])")
                if typ != "OK" or not h or not h[0]:
                    continue
                intest = email.message_from_bytes(h[0][1], policy=email.policy.default)
                oggetto = decodifica(str(intest.get("Subject", "")))
                if filtro and not any(p in oggetto.lower() for p in filtro):
                    # la parola puo' stare anche nel nome del file allegato (es. "Intervento_Rossi.txt") invece che nell'oggetto
                    try:
                        t2, bs = M.fetch(num, "(BODYSTRUCTURE)")
                        struttura = str(bs).lower() if t2 == "OK" else ""
                    except Exception:
                        struttura = ""
                    if not any(p in struttura for p in filtro):
                        continue
                trovate += 1
                chiave = "imap|%s|%s|%s" % (c["imap_utente"], intest.get("Message-ID", ""), oggetto) if intest.get("Message-ID") else "imap|%s|%s|%s" % (c["imap_utente"], intest.get("Date", ""), oggetto)
                if solo_prova:
                    continue
                if chiave in self.visti():
                    self.diag["gia"] += 1
                    continue
                typ, dm = M.fetch(num, "(BODY.PEEK[])")
                if typ != "OK" or not dm or not dm[0]:
                    continue
                msg = email.message_from_bytes(dm[0][1], policy=email.policy.default)
                salvati = 0
                for parte in msg.walk():
                    nome = parte.get_filename()
                    if not nome or parte.is_multipart():
                        continue
                    nome = decodifica(nome)
                    if not nome.lower().endswith(ESTENSIONI):
                        continue
                    dati_p = parte.get_payload(decode=True)
                    if dati_p:
                        self.salva_file(nome, dati_p)
                        salvati += 1
                if not salvati:
                    self.diag["senza"] += 1
                self.segna_visto(chiave)
                nuovi += salvati
            self.diag["trovate"] = trovate
            return trovate if solo_prova else nuovi
        finally:
            try:
                M.logout()
            except Exception:
                pass

    # ---- 3) Outlook classico (Windows)
    def da_outlook(self, c, solo_prova=False):
        if os.name != "nt":
            raise RuntimeError("Outlook si legge solo da Windows.")
        script = r"""
$ErrorActionPreference = 'Stop'
try { $ol = New-Object -ComObject Outlook.Application } catch { Write-Output 'ERRORE|Non riesco ad aprire Outlook. Serve Outlook classico per Windows (non il nuovo Outlook).'; exit 0 }
$ns = $ol.GetNamespace('MAPI')
$cart = $ns.GetDefaultFolder(6)
$dal = (Get-Date).AddDays(-[int]$env:ASS_GIORNI)
$filtri = @(); if ($env:ASS_FILTRO) { $filtri = @($env:ASS_FILTRO -split ';' | Where-Object { $_ }) }
$prova = $env:ASS_PROVA -eq '1'
$visti = @(); if (Test-Path $env:ASS_VISTI) { $visti = @(Get-Content -LiteralPath $env:ASS_VISTI -Encoding UTF8) }
$items = $cart.Items
$items.Sort('[ReceivedTime]', $true)
$n = 0
foreach ($m in $items) {
  if ($m.Class -ne 43) { continue }
  if ($m.ReceivedTime -lt $dal) { break }
  if ($filtri.Count -gt 0) {
    $trovato = $false
    foreach ($f in $filtri) { if ($m.Subject -like ('*' + $f + '*')) { $trovato = $true; break } }
    if (-not $trovato) { foreach ($a in $m.Attachments) { foreach ($f in $filtri) { if ($a.FileName -like ('*' + $f + '*')) { $trovato = $true; break } }; if ($trovato) { break } } }
    if (-not $trovato) { continue }
  }
  $n++
  if ($prova) { continue }
  $id = $m.EntryID
  if ($visti -contains $id) { continue }
  foreach ($a in $m.Attachments) {
    $nome = $a.FileName
    if ($nome -match '\.(zip|txt|json|pdf)$') {
      $dest = Join-Path $env:ASS_ARRIVO ((Get-Date -Format 'yyyyMMdd_HHmmss_') + ($n) + '_' + ($nome -replace '[\\/:*?"<>|]', '_'))
      $a.SaveAsFile($dest)
      Write-Output ('FILE|' + $dest)
    }
  }
  Write-Output ('VISTO|' + $id)
}
Write-Output ('TROVATE|' + $n)
"""
        tmp = tempfile.NamedTemporaryFile("w", suffix=".ps1", delete=False, encoding="utf-8-sig", dir=self.dir)
        tmp.write(script)
        tmp.close()
        # il file con gli id gia' visti, uno per riga
        vp = os.path.join(self.dir, "visti_outlook.txt")
        ids = [k[8:] for k in self.visti() if k.startswith("outlook|")]
        with open(vp, "w", encoding="utf-8") as f:
            f.write("\n".join(ids))
        env = dict(os.environ, ASS_GIORNI=str(int(c.get("giorni", 14))), ASS_FILTRO=";".join(parole_filtro(c.get("filtro"))), ASS_PROVA="1" if solo_prova else "0",
                   ASS_VISTI=vp, ASS_ARRIVO=self.arrivo)
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", tmp.name], env=env,
                               capture_output=True, timeout=180, creationflags=0x08000000, stdin=subprocess.DEVNULL)
        except subprocess.TimeoutExpired:
            raise RuntimeError("Outlook non ha risposto in tempo (forse aspetta una conferma sullo schermo).")
        finally:
            try:
                os.remove(tmp.name)
            except Exception:
                pass
        testo = r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")
        nuovi = trovate = 0
        for riga in testo.splitlines():
            riga = riga.strip()
            if riga.startswith("ERRORE|"):
                raise RuntimeError(riga[7:])
            if riga.startswith("FILE|"):
                nuovi += 1
            elif riga.startswith("VISTO|"):
                self.segna_visto("outlook|" + riga[6:])
            elif riga.startswith("TROVATE|"):
                trovate = int(riga[8:] or 0)
        if r.returncode != 0 and not trovate and not nuovi:
            raise RuntimeError("Lettura di Outlook non riuscita: " + testo.strip()[:200])
        return trovate if solo_prova else nuovi

    # ---- controllo
    def controlla(self, solo_prova=False):
        """Ritorna (numero, messaggio). In prova non scarica nulla."""
        c = self.config()
        m = c["metodo"]
        if m == "nessuno":
            return 0, "Nessun metodo scelto."
        if m == "cartella":
            if solo_prova:
                cs = [x.strip().strip('"') for x in re.split(r"[;\n]", c.get("cartella_osservata") or "") if x.strip()]
                if not cs or not any(os.path.isdir(x) for x in cs):
                    raise RuntimeError("La cartella non esiste: %s" % (cs[0] if cs else "(non scelta)"))
                return 0, "Va bene: %d cartelle trovate." % sum(os.path.isdir(x) for x in cs)
            n = self.da_cartella(c)
            d = getattr(self, "diag", {})
            extra = [x for x in ("%d gia' letti" % d.get("visti", 0) if d.get("visti") else "", "%d non riconosciuti come interventi" % d.get("altri", 0) if d.get("altri") else "",
                                 "%d piu' vecchi di %s giorni" % (d.get("vecchi", 0), c.get("giorni", 14)) if d.get("vecchi") else "") if x]
            return n, "%d file nuovi dalla cartella%s." % (n, " (" + ", ".join(extra) + ")" if extra else "")
        if m == "imap":
            n = self.da_imap(c, solo_prova)
            d = getattr(self, "diag", {})
            guardati = "Ho guardato %d messaggi della cartella «%s» degli ultimi %s giorni; " % (d.get("guardati", 0), c.get("imap_cartella") or "INBOX", c.get("giorni"))
            if solo_prova:
                return n, "Collegamento riuscito. %s%d contengono «%s» nell'oggetto o nel nome del file." % (guardati, n, c.get("filtro", ""))
            extra = [x for x in ("%d gia' letti" % d.get("gia", 0) if d.get("gia") else "", "%d senza allegati .txt/.zip/.json/.pdf" % d.get("senza", 0) if d.get("senza") else "") if x]
            return n, "%s%d con «%s»; %d file nuovi dalla posta%s." % (guardati, d.get("trovate", 0), c.get("filtro", ""), n, " (" + ", ".join(extra) + ")" if extra else "")
        if m == "outlook":
            n = self.da_outlook(c, solo_prova)
            return n, ("Outlook risponde: %d messaggi con «%s» negli ultimi %s giorni." % (n, c.get("filtro", ""), c.get("giorni")) if solo_prova else "%d file nuovi da Outlook." % n)
        return 0, ""

    def esegui(self, solo_prova=False):
        with self.blocco:
            if self.run["in_corso"]:
                return {"ok": False, "messaggio": "Controllo gia' in corso."}
            self.run["in_corso"] = True
        try:
            n, msg = self.controlla(solo_prova)
            esito = {"ok": True, "nuovi": n, "messaggio": msg}
        except Exception as e:
            esito = {"ok": False, "nuovi": 0, "messaggio": str(e) or e.__class__.__name__}
        finally:
            self.run["in_corso"] = False
        if not solo_prova:
            self.run.update(ultimo=datetime.datetime.now().isoformat(timespec="seconds"), esito=("ok: " if esito["ok"] else "errore: ") + esito["messaggio"], nuovi=esito["nuovi"])
        return esito

    def stato(self):
        return dict(self.run, config=self.config_pubblica(), in_attesa=len(self.elenco()))

    def avvia(self):
        threading.Thread(target=self.recupera_allegati, daemon=True).start()

        def ciclo():
            ultimo = 0.0
            while True:
                self.subito.wait(5)
                forza = self.subito.is_set()
                self.subito.clear()
                c = self.config()
                if c["metodo"] == "nessuno":
                    continue
                attesa = 1 if c["metodo"] == "cartella" else max(1, int(c.get("minuti", 3)))      # guardare una cartella costa niente: ogni minuto
                if forza or time.time() - ultimo >= attesa * 60:
                    ultimo = time.time()
                    try:
                        self.esegui()
                    except Exception:
                        pass
        threading.Thread(target=ciclo, daemon=True).start()
