# -*- coding: utf-8 -*-
"""
Assistenza impianti - LICENZA (parte per l'ufficio)

Come funziona, in breve:
  - ogni PC ha un CODICE DI INSTALLAZIONE (calcolato dal PC, es. K7QM-2XPD-9WTA);
  - il venditore, con il suo strumento privato (genera_licenza.py), crea una CHIAVE legata al nome dell'azienda,
    al codice del PC e a una scadenza (oppure senza scadenza);
  - la chiave e' firmata (Ed25519): questo programma ha solo la chiave PUBBLICA (licenza_pubblica.txt),
    quindi puo' controllare una chiave ma non crearne di nuove;
  - senza chiave l'app dell'ufficio funziona in PROVA per 30 giorni dal primo avvio; poi chiede la chiave.
    L'app dei tecnici non e' toccata dalla licenza.

Nessun collegamento a internet, nessun server.
Il controllo e' un deterrente onesto, non una cassaforte: chi sa programmare puo' aggirarlo.
"""
import base64
import datetime
import hashlib
import json
import os
import socket
import sys
import uuid

GIORNI_PROVA = 30
TECNICI_PROVA = 3            # tecnici ammessi durante la prova gratuita (0 = senza limite)
PREFISSO = "ASS1"

# ------------------------------------------------------------------ Ed25519 (RFC 8032), solo libreria standard
_P = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_I = pow(2, (_P - 1) // 4, _P)


def _inv(x):
    return pow(x, _P - 2, _P)


def _xrec(y):
    x2 = (y * y - 1) * _inv(_D * y * y + 1) % _P
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P:
        x = x * _I % _P
    if x & 1:
        x = _P - x
    return x


_BY = 4 * _inv(5) % _P
_B = (_xrec(_BY), _BY, 1, _xrec(_BY) * _BY % _P)
_ZERO = (0, 1, 1, 0)


def _somma(p, q):
    a = (p[1] - p[0]) * (q[1] - q[0]) % _P
    b = (p[1] + p[0]) * (q[1] + q[0]) % _P
    c = 2 * p[3] * q[3] * _D % _P
    d = 2 * p[2] * q[2] % _P
    e, f, g, h = b - a, d - c, d + c, b + a
    return (e * f % _P, g * h % _P, f * g % _P, e * h % _P)


def _molt(p, e):
    q = _ZERO
    while e:
        if e & 1:
            q = _somma(q, p)
        p = _somma(p, p)
        e >>= 1
    return q


def _codifica(p):
    zi = _inv(p[2])
    x, y = p[0] * zi % _P, p[1] * zi % _P
    return (y | ((x & 1) << 255)).to_bytes(32, "little")


def _decodifica(b):
    if len(b) != 32:
        raise ValueError("lunghezza")
    y = int.from_bytes(b, "little")
    segno = y >> 255
    y &= (1 << 255) - 1
    if y >= _P:
        raise ValueError("punto non valido")
    x = _xrec(y)
    if (x & 1) != segno:
        x = _P - x
    p = (x, y, 1, x * y % _P)
    if (-p[0] * p[0] + p[1] * p[1] - 1 - _D * p[0] * p[0] * p[1] * p[1]) % _P:
        raise ValueError("punto non valido")
    return p


def _h(m):
    return int.from_bytes(hashlib.sha512(m).digest(), "little")


def _segreto(sk):
    h = hashlib.sha512(sk).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def chiave_pubblica(sk):
    a, _ = _segreto(sk)
    return _codifica(_molt(_B, a))


def firma(sk, msg):
    a, pref = _segreto(sk)
    pk = _codifica(_molt(_B, a))
    r = _h(pref + msg) % _L
    R = _codifica(_molt(_B, r))
    s = (r + _h(R + pk + msg) * a) % _L
    return R + s.to_bytes(32, "little")


def verifica(pk, msg, sig):
    try:
        if len(sig) != 64 or len(pk) != 32:
            return False
        R = _decodifica(sig[:32])
        A = _decodifica(pk)
        s = int.from_bytes(sig[32:], "little")
        if s >= _L:
            return False
        k = _h(sig[:32] + pk + msg) % _L
        sb = _molt(_B, s)
        rk = _somma(R, _molt(A, k))
        return _codifica(sb) == _codifica(rk)
    except Exception:
        return False


# ------------------------------------------------------------------ chiave di licenza
def _b64(b):
    return base64.urlsafe_b64encode(b).decode("ascii").rstrip("=")


def _unb64(t):
    t = t.strip()
    return base64.urlsafe_b64decode(t + "=" * (-len(t) % 4))


def crea_chiave(sk, azienda, codice, scadenza="", note="", tecnici=0):
    """Solo per il venditore. scadenza: 'AAAA-MM-GG' oppure '' (nessuna). codice: quello del PC del cliente, oppure '*' (qualsiasi PC).
    tecnici: numero massimo di tecnici attivi (0 = senza limite)."""
    dati = {"a": azienda.strip(), "i": normalizza_codice(codice) if codice != "*" else "*", "s": scadenza.strip(),
            "e": datetime.date.today().isoformat()}
    if note:
        dati["n"] = note
    if tecnici and int(tecnici) > 0:
        dati["t"] = int(tecnici)
    payload = json.dumps(dati, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return "%s.%s.%s" % (PREFISSO, _b64(payload), _b64(firma(sk, payload)))


def _it(iso):
    try:
        return datetime.date.fromisoformat(iso).strftime("%d/%m/%Y")
    except Exception:
        return iso


def normalizza_codice(c):
    return "".join(ch for ch in (c or "").upper() if ch.isalnum())


def _n_tecnici(d):
    """Numero di tecnici ammessi dalla licenza (0 = senza limite; le chiavi senza il campo non hanno limite)."""
    try:
        return max(0, int(d.get("t") or 0))
    except Exception:
        return 0


def leggi_chiave(pk, testo):
    """Ritorna (dati, errore). dati = dict della licenza se la firma e' valida."""
    t = "".join((testo or "").split())
    try:
        pre, p, f = t.split(".")
        if pre != PREFISSO:
            return None, "La chiave non è di questo programma."
        payload, sig = _unb64(p), _unb64(f)
    except Exception:
        return None, "La chiave non è scritta bene: copiala per intero, senza spazi in più."
    if not verifica(pk, payload, sig):
        return None, "La chiave non è valida (firma non corretta)."
    try:
        return json.loads(payload.decode("utf-8")), ""
    except Exception:
        return None, "La chiave non è leggibile."


# ------------------------------------------------------------------ questo PC
def _id_macchina():
    """Identificativo stabile del PC (non cambia reinstallando il programma)."""
    if sys.platform.startswith("win"):
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0, winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0)) as k:
                return str(winreg.QueryValueEx(k, "MachineGuid")[0])
        except Exception:
            pass
    for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            with open(p) as f:
                return f.read().strip()
        except Exception:
            pass
    return "%s-%012x" % (socket.gethostname(), uuid.getnode())


def codice_installazione():
    h = hashlib.sha256(("assistenza|" + _id_macchina()).encode("utf-8")).digest()
    s = base64.b32encode(h).decode("ascii")[:12]
    return "%s-%s-%s" % (s[:4], s[4:8], s[8:12])


class Licenza:
    def __init__(self, radice, cartella_programma):
        self.dir = os.path.join(radice, "licenza")
        os.makedirs(self.dir, exist_ok=True)
        self.file_chiave = os.path.join(self.dir, "chiave.txt")
        self.file_prova = os.path.join(self.dir, "prova.json")
        self.pk = None
        for p in (os.path.join(cartella_programma, "licenza_pubblica.txt"),):
            try:
                with open(p, encoding="utf-8") as f:
                    self.pk = bytes.fromhex(f.read().strip())
            except Exception:
                pass
        self.codice = codice_installazione()

    # inizio della prova: file + (su Windows) registro, vale il piu' vecchio: cancellare la cartella non azzera la prova
    def _inizio_prova(self):
        date = []
        try:
            with open(self.file_prova, encoding="utf-8") as f:
                date.append(json.load(f)["inizio"])
        except Exception:
            pass
        if sys.platform.startswith("win"):
            try:
                import winreg
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\AssistenzaImpianti", 0, winreg.KEY_READ) as k:
                    date.append(winreg.QueryValueEx(k, "Prima")[0])
            except Exception:
                pass
        date = [d for d in date if isinstance(d, str) and len(d) == 10]
        inizio = min(date) if date else datetime.date.today().isoformat()
        try:
            with open(self.file_prova, "w", encoding="utf-8") as f:
                json.dump({"inizio": inizio}, f)
        except Exception:
            pass
        if sys.platform.startswith("win"):
            try:
                import winreg
                with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\AssistenzaImpianti") as k:
                    winreg.SetValueEx(k, "Prima", 0, winreg.REG_SZ, inizio)
            except Exception:
                pass
        return datetime.date.fromisoformat(inizio)

    def stato(self):
        oggi = datetime.date.today()
        out = {"codice": self.codice, "giorni_prova": GIORNI_PROVA}
        chiave = ""
        try:
            with open(self.file_chiave, encoding="utf-8") as f:
                chiave = f.read().strip()
        except Exception:
            pass
        errore = ""
        if chiave:
            if self.pk is None:
                errore = "Manca licenza_pubblica.txt: reinstalla il programma."
            else:
                d, errore = leggi_chiave(self.pk, chiave)
                if d:
                    if d.get("i") not in ("*", normalizza_codice(self.codice)):
                        errore = "Questa chiave è stata fatta per un altro computer."
                    else:
                        scad = d.get("s") or ""
                        try:
                            giorni = (datetime.date.fromisoformat(scad) - oggi).days if scad else None
                        except Exception:
                            giorni = None
                        if scad and (giorni is None or giorni < 0):
                            out.update(stato="scaduta", azienda=d.get("a", ""), scadenza=scad, ok=False, tecnici=_n_tecnici(d),
                                       messaggio="La licenza è scaduta il %s. Chiedi la chiave di rinnovo." % _it(scad))
                            return out
                        out.update(stato="licenza", azienda=d.get("a", ""), scadenza=scad, giorni=giorni, ok=True, tecnici=_n_tecnici(d),
                                   messaggio="Licenza attiva" + (" fino al %s" % _it(scad) if scad else " (senza scadenza)") + ".")
                        return out
        inizio = self._inizio_prova()
        trascorsi = max(0, (oggi - inizio).days)
        residui = GIORNI_PROVA - trascorsi
        if residui > 0:
            out.update(stato="prova", ok=True, giorni=residui, errore_chiave=errore, tecnici=TECNICI_PROVA,
                       messaggio="Prova gratuita: restano %d %s." % (residui, "giorno" if residui == 1 else "giorni"))
        else:
            out.update(stato="prova_finita", ok=False, giorni=0, errore_chiave=errore, tecnici=TECNICI_PROVA,
                       messaggio="La prova gratuita di %d giorni è finita. Inserisci la chiave di licenza per continuare." % GIORNI_PROVA)
        return out

    def attiva(self, testo):
        if self.pk is None:
            return {"ok": False, "messaggio": "Manca licenza_pubblica.txt: reinstalla il programma."}
        d, err = leggi_chiave(self.pk, testo)
        if not d:
            return {"ok": False, "messaggio": err}
        if d.get("i") not in ("*", normalizza_codice(self.codice)):
            return {"ok": False, "messaggio": "Questa chiave è stata fatta per un altro computer (codice %s)." % d.get("i")}
        try:
            if d.get("s") and datetime.date.fromisoformat(d["s"]) < datetime.date.today():
                return {"ok": False, "messaggio": "Questa chiave è già scaduta il %s." % _it(d["s"])}
        except Exception:
            return {"ok": False, "messaggio": "La data di scadenza della chiave non è leggibile."}
        with open(self.file_chiave, "w", encoding="utf-8") as f:
            f.write("".join(testo.split()))
        s = self.stato()
        s["messaggio"] = "Licenza attivata per " + d.get("a", "") + (" (%d %s)." % (_n_tecnici(d), "tecnico" if _n_tecnici(d) == 1 else "tecnici") if _n_tecnici(d) else ".")
        return dict(s, ok=True, stato="licenza")
