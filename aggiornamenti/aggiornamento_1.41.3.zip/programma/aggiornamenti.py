# -*- coding: utf-8 -*-
"""
Assistenza impianti - AGGIORNAMENTI DEL PROGRAMMA PER L'UFFICIO

Come funziona, in breve:
  1. Il venditore pubblica, su un indirizzo internet pubblico qualsiasi (per esempio GitHub Pages), due cose:
       - versione-stabile.json   (numero dell'ultima versione, novita', impronta e FIRMA del pacchetto)
       - aggiornamento_<versione>.zip   (i file nuovi del programma)
  2. Il servizio dell'ufficio, una volta al giorno, legge versione-<canale>.json. Se c'e' una versione piu' nuova lo
     scrive nelle Impostazioni: non installa niente da solo (salvo che l'ufficio abbia scelto l'installazione di notte).
  3. Quando l'operatore preme "Installa", il programma:
       a) scarica il pacchetto e controlla che l'impronta (SHA-256) coincida con quella del file .json;
       b) controlla la FIRMA digitale: e' fatta con la chiave privata del venditore (la stessa delle licenze, ma con
          un'etichetta diversa); qui c'e' solo la chiave pubblica (licenza_pubblica.txt), che controlla ma non puo' firmare.
          Un pacchetto manomesso o non fatto dal venditore NON viene installato;
       c) prova i file nuovi in una cartella a parte (devono almeno caricarsi senza errori);
       d) salva una copia della versione attuale;
       e) sostituisce i file e riavvia il servizio;
       f) un piccolo "guardiano" separato controlla che il servizio nuovo risponda entro due minuti e mostri la versione
          nuova; se no, rimette la copia di prima e riavvia da solo.
     Non si toccano mai: dati, impostazioni, posta, licenza, esportazioni, backup.

Serve internet solo per leggere questi due file; nessun dato dell'azienda esce dal PC.
"""
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import zipfile

import licenza

ETICHETTA = b"ASSAGG1"                       # etichetta della firma: separa le firme degli aggiornamenti da quelle delle licenze
CANALI = ("stabile", "prova")
CARTELLE_OK = ("programma", "app")           # nel pacchetto si possono mettere solo file di queste due cartelle
ESTENSIONI_OK = (".py", ".html", ".js", ".css", ".png", ".webmanifest", ".json", ".txt", ".ico")
MAX_PACCHETTO = 80 * 1024 * 1024
MAX_SCOMPATTATO = 250 * 1024 * 1024
ORE_CONTROLLO = 24


def messaggio_da_firmare(versione, canale, sha256_hex):
    return ETICHETTA + b"|" + versione.encode("ascii") + b"|" + canale.encode("ascii") + b"|" + sha256_hex.lower().encode("ascii")


def v_tuple(v):
    n = [int(x) for x in re.findall(r"\d+", str(v).split(" ")[0])[:3]]
    return tuple(n + [0] * (3 - len(n)))


GUARDIANO = r'''# -*- coding: utf-8 -*-
# Guardiano dell'aggiornamento: controlla che il servizio nuovo parta; se no, rimette la versione di prima.
import json, os, shutil, subprocess, sys, time, urllib.request
radice, porta, nuova, python, dopo = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4], float(sys.argv[5])
cart = os.path.join(radice, "aggiornamenti")
prova = os.path.join(cart, "in_prova.json")
def scrivi_stato(msg):
    try:
        p = os.path.join(cart, "stato.json")
        try:
            s = json.load(open(p, encoding="utf-8"))
        except Exception:
            s = {}
        s["esito_ultimo"] = msg
        json.dump(s, open(p, "w", encoding="utf-8"), ensure_ascii=False)
    except Exception:
        pass
def sano():
    try:
        r = urllib.request.urlopen("http://127.0.0.1:%d/aggiorna-stato" % porta, timeout=4)
        d = json.loads(r.read().decode("utf-8"))
        return d.get("versione") == nuova and float(d.get("avviato") or 0) > dopo
    except Exception:
        return False
durata = float(os.environ.get("ASS_GUARDIANO_SEC") or 150)
time.sleep(min(15, durata / 5))
fine = time.time() + durata
while time.time() < fine:
    if sano():
        try: os.remove(prova)
        except Exception: pass
        scrivi_stato("Aggiornato alla versione %s." % nuova)
        sys.exit(0)
    time.sleep(5)
# non risponde: si torna indietro
prec = os.path.join(cart, "precedente")
try:
    for rad, _, files in os.walk(prec):
        for n in files:
            if n == "versione.txt": continue
            src = os.path.join(rad, n); dst = os.path.join(radice, os.path.relpath(src, prec))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst + ".ripr"); os.replace(dst + ".ripr", dst)
    argv = json.load(open(prova, encoding="utf-8")).get("argv") or []
except Exception:
    argv = []
try:
    pid = int(open(os.path.join(cart, "servizio.pid")).read().strip())
    if os.name == "nt":
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True, creationflags=0x08000000)
    else:
        import signal; os.kill(pid, signal.SIGKILL)
except Exception:
    pass
time.sleep(2)
try: os.remove(prova)
except Exception: pass
scrivi_stato("L'aggiornamento alla versione %s non e' partito: e' stata rimessa la versione di prima." % nuova)
args = [python, os.path.join(radice, "programma", "servizio_ufficio.py")] + [a for a in argv if a != "--senza-browser"] + ["--senza-browser"]
if os.name == "nt":
    subprocess.Popen(args, creationflags=0x08000000 | 0x00000008, close_fds=True)
else:
    subprocess.Popen(args, close_fds=True, start_new_session=True)
'''


class Aggiornamenti:
    def __init__(self, radice, cartella_programma, cartella_app, porta=8088, riavvia=None, occupato=None):
        self.radice = radice
        self.prog = cartella_programma
        self.app = cartella_app
        self.porta = porta
        self.riavvia = riavvia or (lambda: None)
        self.occupato = occupato or (lambda: False)
        self.dir = os.path.join(radice, "aggiornamenti")
        os.makedirs(self.dir, exist_ok=True)
        self.avviato = time.time()
        try:
            with open(os.path.join(self.dir, "servizio.pid"), "w") as f:      # serve al guardiano per fermare un servizio che non risponde
                f.write(str(os.getpid()))
        except Exception:
            pass
        self.blocco = threading.Lock()
        self.fase = ""
        self.in_corso = False
        self.risultato = None
        self.pk = None
        try:
            with open(os.path.join(cartella_programma, "licenza_pubblica.txt"), encoding="utf-8") as f:
                self.pk = bytes.fromhex(f.read().strip())
        except Exception:
            pass

    # ------------------------------------------------------------------ impostazioni e stato (file json nella cartella aggiornamenti)
    def _leggi(self, nome, predefinito):
        try:
            with open(os.path.join(self.dir, nome), encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, type(predefinito)) else predefinito
        except Exception:
            return predefinito

    def _scrivi(self, nome, dati):
        p = os.path.join(self.dir, nome)
        with open(p + ".tmp", "w", encoding="utf-8") as f:
            json.dump(dati, f, ensure_ascii=False, indent=1)
        os.replace(p + ".tmp", p)

    def config(self):
        c = {"url": "", "canale": "stabile", "auto": False}
        c.update(self._leggi("config.json", {}))
        if not c["url"]:
            try:
                with open(os.path.join(self.prog, "aggiornamenti_url.txt"), encoding="utf-8") as f:
                    righe = [r.strip() for r in f.read().splitlines() if r.strip() and not r.strip().startswith("#")]
                c["url"] = self._url_pulito(righe[0]) if righe and not righe[0].upper().startswith("INSERISCI") else ""
            except Exception:
                pass
        if c["canale"] not in CANALI:
            c["canale"] = "stabile"
        return c

    def salva_config(self, nuova):
        c = self._leggi("config.json", {})
        if "url" in nuova:
            c["url"] = self._url_pulito(str(nuova.get("url") or ""))
        if nuova.get("canale") in CANALI:
            c["canale"] = nuova["canale"]
        if "auto" in nuova:
            c["auto"] = bool(nuova["auto"])
        self._scrivi("config.json", c)
        return self.config()

    @staticmethod
    def _url_pulito(u):
        u = u.strip().rstrip("/")
        if u and not (u.startswith("https://") or re.match(r"^http://(localhost|127\.0\.0\.1)(:\d+)?(/|$)", u)):
            return ""
        return u

    def versione_installata(self):
        try:
            with open(os.path.join(self.app, "index.html"), encoding="utf-8", errors="replace") as f:
                m = re.search(r"VERSIONE_APP = '(\d+(?:\.\d+){1,2})", f.read())
            return m.group(1) if m else "0.0.0"
        except Exception:
            return "0.0.0"

    def stato(self):
        s = self._leggi("stato.json", {})
        c = self.config()
        disp = s.get("disponibile") or None
        inst = self.versione_installata()
        if disp and v_tuple(disp.get("versione")) <= v_tuple(inst):
            disp = None
        prec = ""
        try:
            with open(os.path.join(self.dir, "precedente", "versione.txt"), encoding="utf-8") as f:
                prec = f.read().strip()
        except Exception:
            pass
        ult = self._leggi("ultimo.json", None)
        if not ult and prec:                      # aggiornamenti fatti da una versione che non scriveva ultimo.json
            try:
                ult = {"quando": datetime.datetime.fromtimestamp(os.path.getmtime(os.path.join(self.dir, "precedente", "versione.txt"))).strftime("%Y-%m-%d %H:%M"), "da": prec, "a": inst}
            except Exception:
                ult = None
        return {"ok": True, "ultimo_agg": ult, "versione": inst, "avviato": self.avviato, "url": c["url"], "canale": c["canale"], "auto": c["auto"],
                "ultimo_controllo": s.get("ultimo_controllo", ""), "errore": s.get("errore", ""),
                "disponibile": ({k: disp.get(k) for k in ("versione", "data", "novita", "canale", "minima")} if disp else None),
                "in_corso": self.in_corso, "fase": self.fase, "risultato": self.risultato, "precedente": prec, "esito_ultimo": s.get("esito_ultimo", ""),
                "firma_pronta": self.pk is not None}

    # ------------------------------------------------------------------ rete
    def _scarica(self, url, massimo, timeout=40):
        if not self._url_pulito(url):
            raise RuntimeError("Indirizzo degli aggiornamenti non valido (deve iniziare con https://).")
        req = urllib.request.Request(url, headers={"User-Agent": "AssistenzaImpianti-Aggiornamenti"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            dati = r.read(massimo + 1)
        if len(dati) > massimo:
            raise RuntimeError("File troppo grande.")
        return dati

    # ------------------------------------------------------------------ controllo
    def controlla(self):
        s = self._leggi("stato.json", {})
        c = self.config()
        s["ultimo_controllo"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        try:
            if not c["url"]:
                raise RuntimeError("Indirizzo degli aggiornamenti non impostato.")
            dati = json.loads(self._scarica("%s/versione-%s.json" % (c["url"], c["canale"]), 200000).decode("utf-8"))
            for k in ("versione", "pacchetto", "sha256", "firma"):
                if not isinstance(dati.get(k), str) or not dati[k]:
                    raise RuntimeError("Il file delle versioni non e' completo.")
            if not re.match(r"^\d+(\.\d+){1,2}$", dati["versione"]) or not re.match(r"^[0-9a-fA-F]{64}$", dati["sha256"]) \
                    or not re.match(r"^[A-Za-z0-9_.\-]+\.zip$", dati["pacchetto"]):
                raise RuntimeError("Il file delle versioni non e' valido.")
            if dati.get("canale", c["canale"]) != c["canale"]:
                raise RuntimeError("Il file delle versioni e' di un altro canale.")
            dati["canale"] = c["canale"]
            nov = dati.get("novita")
            dati["novita"] = [str(x)[:200] for x in nov[:12]] if isinstance(nov, list) else []
            s["disponibile"] = dati
            s["errore"] = ""
        except Exception as e:
            s["errore"] = "Controllo non riuscito: %s" % (str(e) or e.__class__.__name__)
        self._scrivi("stato.json", s)
        return self.stato()

    # ------------------------------------------------------------------ installazione
    def _file_sicuri(self, zf):
        """Elenco dei file del pacchetto, solo se tutti sono ammessi. Solleva un errore altrimenti."""
        tot = 0
        nomi = []
        for i in zf.infolist():
            if i.is_dir():
                continue
            n = i.filename.replace("\\", "/")
            parti = n.split("/")
            if n.startswith("/") or ".." in parti or ":" in n or parti[0] not in CARTELLE_OK or len(parti) < 2:
                raise RuntimeError("Il pacchetto contiene un percorso non ammesso: %s" % n)
            if not n.lower().endswith(ESTENSIONI_OK):
                raise RuntimeError("Il pacchetto contiene un tipo di file non ammesso: %s" % n)
            if parti[0] == "programma" and (len(parti) != 2 or not (n.endswith(".py") or n.endswith(".txt"))):
                raise RuntimeError("Nella cartella programma sono ammessi solo file .py e .txt: %s" % n)
            if n.lower().endswith(("licenza_pubblica.txt", "aggiornamenti_url.txt")):
                raise RuntimeError("Il pacchetto non puo' cambiare la chiave pubblica o l'indirizzo degli aggiornamenti.")
            tot += i.file_size
            if tot > MAX_SCOMPATTATO:
                raise RuntimeError("Pacchetto troppo grande.")
            nomi.append(n)
        if not nomi:
            raise RuntimeError("Il pacchetto e' vuoto.")
        return nomi

    def _prova_caricamento(self, staging):
        """I file .py nuovi, messi al posto dei vecchi in una copia, devono caricarsi senza errori."""
        prova = os.path.join(self.dir, "prova_programma")
        shutil.rmtree(prova, ignore_errors=True)
        os.makedirs(prova)
        for n in os.listdir(self.prog):
            if n.endswith((".py", ".txt")):
                shutil.copy2(os.path.join(self.prog, n), os.path.join(prova, n))
        nuovo = os.path.join(staging, "programma")
        if os.path.isdir(nuovo):
            for n in os.listdir(nuovo):
                shutil.copy2(os.path.join(nuovo, n), os.path.join(prova, n))
        codice = "import sys; sys.path.insert(0, %r); import servizio_ufficio, posta_automatica, licenza, aggiornamenti" % prova
        r = subprocess.run([sys.executable, "-c", codice], capture_output=True, timeout=60, stdin=subprocess.DEVNULL,
                           creationflags=0x08000000 if os.name == "nt" else 0, cwd=prova)
        shutil.rmtree(prova, ignore_errors=True)
        if r.returncode != 0:
            raise RuntimeError("I file nuovi non si caricano: %s" % (r.stderr.decode("utf-8", "replace").strip().splitlines() or ["errore"])[-1][:200])

    def _copia_precedente(self, nomi_nuovi, versione):
        prec = os.path.join(self.dir, "precedente")
        shutil.rmtree(prec, ignore_errors=True)
        os.makedirs(prec)
        # tutta la cartella programma (.py/.txt) e tutta l'app: cosi' il ritorno indietro e' completo
        for n in os.listdir(self.prog):
            if n.endswith((".py", ".txt")):
                os.makedirs(os.path.join(prec, "programma"), exist_ok=True)
                shutil.copy2(os.path.join(self.prog, n), os.path.join(prec, "programma", n))
        if os.path.isdir(self.app):
            shutil.copytree(self.app, os.path.join(prec, "app"))
        with open(os.path.join(prec, "versione.txt"), "w", encoding="utf-8") as f:
            f.write(versione)

    def _applica(self, origine, nomi):
        for n in nomi:
            dst = os.path.join(self.radice, n.replace("/", os.sep))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(os.path.join(origine, n.replace("/", os.sep)), dst + ".nuovo")
            os.replace(dst + ".nuovo", dst)

    def _riavvia_con_guardiano(self, nuova_versione, argv, da=""):
        argv = [x for x in (argv or [])[1:]] if argv and str(argv[0]).lower().endswith(".py") else list(argv or [])      # senza il nome dello script
        self._scrivi("in_prova.json", {"da": da, "a": nuova_versione, "quando": time.time(), "argv": argv})
        self._scrivi("ultimo.json", {"quando": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "da": da, "a": nuova_versione})
        g = os.path.join(self.dir, "guardiano.py")
        with open(g, "w", encoding="utf-8") as f:
            f.write(GUARDIANO)
        args = [sys.executable, g, self.radice, str(self.porta), nuova_versione, sys.executable, str(time.time())]
        if os.name == "nt":
            subprocess.Popen(args, creationflags=0x08000000 | 0x00000008, close_fds=True, stdin=subprocess.DEVNULL)
        else:
            subprocess.Popen(args, close_fds=True, stdin=subprocess.DEVNULL, start_new_session=True)
        self.riavvia()

    def installa(self, argv=None):
        """Scarica, controlla, prova, installa. Ritorna {"ok", "messaggio"}. Va chiamata da un thread."""
        if not self.blocco.acquire(blocking=False):
            return {"ok": False, "messaggio": "Un aggiornamento e' gia' in corso."}
        self.in_corso = True
        try:
            if self.pk is None:
                return {"ok": False, "messaggio": "Manca licenza_pubblica.txt: non posso controllare la firma. Reinstalla il programma."}
            s = self._leggi("stato.json", {})
            d = s.get("disponibile")
            if not d:
                return {"ok": False, "messaggio": "Nessun aggiornamento da installare: premi prima «Controlla ora»."}
            inst = self.versione_installata()
            if v_tuple(d["versione"]) <= v_tuple(inst):
                return {"ok": False, "messaggio": "La versione installata e' gia' aggiornata."}
            if d.get("minima") and v_tuple(inst) < v_tuple(d["minima"]):
                return {"ok": False, "messaggio": "Questa versione richiede prima l'aggiornamento alla %s (reinstalla con il Setup)." % d["minima"]}
            c = self.config()
            self.fase = "Scarico il pacchetto…"
            dati = self._scarica("%s/%s" % (c["url"], d["pacchetto"]), MAX_PACCHETTO, timeout=120)
            self.fase = "Controllo l'impronta e la firma…"
            if hashlib.sha256(dati).hexdigest().lower() != d["sha256"].lower():
                return {"ok": False, "messaggio": "Il pacchetto scaricato non corrisponde all'impronta dichiarata: NON installato."}
            try:
                firma = licenza._unb64(d["firma"])
            except Exception:
                firma = b""
            if not licenza.verifica(self.pk, messaggio_da_firmare(d["versione"], c["canale"], d["sha256"]), firma):
                return {"ok": False, "messaggio": "La firma del pacchetto NON e' valida: non e' stato fatto dal venditore o e' stato manomesso. NON installato."}
            self.fase = "Controllo i file…"
            staging = os.path.join(self.dir, "nuovo")
            shutil.rmtree(staging, ignore_errors=True)
            os.makedirs(staging)
            pz = os.path.join(self.dir, "pacchetto.zip")
            with open(pz, "wb") as f:
                f.write(dati)
            with zipfile.ZipFile(pz) as zf:
                nomi = self._file_sicuri(zf)
                zf.extractall(staging)
            self.fase = "Provo i file nuovi…"
            self._prova_caricamento(staging)
            self.fase = "Salvo la versione attuale…"
            self._copia_precedente(nomi, inst)
            self.fase = "Installo e riavvio…"
            self._applica(staging, nomi)
            shutil.rmtree(staging, ignore_errors=True)
            try:
                os.remove(pz)
            except Exception:
                pass
            s["esito_ultimo"] = "Installazione della versione %s in corso…" % d["versione"]
            self._scrivi("stato.json", s)
            self._riavvia_con_guardiano(d["versione"], list(argv if argv is not None else sys.argv), inst)
            return {"ok": True, "messaggio": "Aggiornamento installato: il programma si riavvia, ricarica la pagina tra un minuto."}
        except Exception as e:
            return {"ok": False, "messaggio": "Aggiornamento non riuscito (nulla e' stato cambiato o e' stato rimesso a posto): %s" % (str(e) or e.__class__.__name__)}
        finally:
            self.fase = ""
            self.in_corso = False
            self.blocco.release()

    def torna_indietro(self, argv=None):
        """Rimette la versione salvata prima dell'ultimo aggiornamento."""
        if not self.blocco.acquire(blocking=False):
            return {"ok": False, "messaggio": "Un aggiornamento e' gia' in corso."}
        self.in_corso = True
        try:
            prec = os.path.join(self.dir, "precedente")
            try:
                with open(os.path.join(prec, "versione.txt"), encoding="utf-8") as f:
                    vecchia = f.read().strip()
            except Exception:
                return {"ok": False, "messaggio": "Non c'e' nessuna versione precedente salvata."}
            nomi = []
            for rad, _, files in os.walk(prec):
                for n in files:
                    if n != "versione.txt":
                        nomi.append(os.path.relpath(os.path.join(rad, n), prec).replace(os.sep, "/"))
            self._applica(prec, nomi)
            self._riavvia_con_guardiano(vecchia, list(argv if argv is not None else sys.argv), self.versione_installata())
            return {"ok": True, "messaggio": "Rimessa la versione %s: il programma si riavvia." % vecchia}
        except Exception as e:
            return {"ok": False, "messaggio": "Non sono riuscito a tornare indietro: %s" % (str(e) or e.__class__.__name__)}
        finally:
            self.in_corso = False
            self.blocco.release()

    def in_background(self, funzione, argv=None):
        """Avvia installa o torna_indietro senza far aspettare l'app; l'esito si legge poi da stato()['risultato']."""
        if self.in_corso:
            return False
        self.risultato = None

        def _v():
            self.risultato = funzione(argv)
        threading.Thread(target=_v, daemon=True).start()
        return True

    # ------------------------------------------------------------------ ciclo in background
    def avvia(self, argv=None):
        threading.Thread(target=self._ciclo, args=(argv,), daemon=True).start()

    def _ciclo(self, argv):
        time.sleep(120)
        while True:
            try:
                c = self.config()
                s = self._leggi("stato.json", {})
                ult = s.get("ultimo_controllo", "")
                scaduto = True
                try:
                    scaduto = (datetime.datetime.now() - datetime.datetime.strptime(ult, "%Y-%m-%d %H:%M")).total_seconds() > ORE_CONTROLLO * 3600
                except Exception:
                    pass
                if c["url"] and scaduto:
                    self.controlla()
                if c["auto"] and c["url"] and 2 <= datetime.datetime.now().hour < 5 and not self.occupato():
                    st = self.stato()
                    if st.get("disponibile") and not st["in_corso"]:
                        self.installa(argv)
            except Exception:
                pass
            time.sleep(1800)
