# -*- coding: utf-8 -*-
"""
Assistenza impianti - SERVIZIO PER L'UFFICIO

Gira sul PC dell'ufficio (di solito quello di Levante). Fa due cose, senza internet e senza server esterni:
  1. apre l'app dal PC stesso (http://localhost:8088/): e' la stessa app dei tecnici, in una copia locale;
  2. mette a disposizione dell'app l'ultimo file Esportazione_....zip creato da Esporta_Levante: l'app lo vede da sola
     e si aggiorna ogni pochi minuti, senza dover scegliere nessun file.

L'esportazione da Levante resta quella di sempre (Esporta_Levante.bat, anche pianificata ogni 15 minuti).
Questo programma non tocca Levante e non scrive nulla nel database.

Uso:   python servizio_ufficio.py [--porta 8088] [--rete] [--senza-browser]
  --rete            rende l'app raggiungibile anche dagli altri PC dell'ufficio (http://nome-pc:8088/). Attenzione: i dati
                    dei clienti sono visibili a chi e' nella stessa rete. Senza questa opzione solo questo PC li vede.
  --senza-browser   non apre il browser (per l'avvio automatico con Windows)
"""
import argparse
import base64
import datetime
import glob
import hashlib
import hmac
import http.cookies
import http.server
import json
import os
import atexit
import secrets
import shutil
import signal
import socket
import socketserver
import subprocess
import sys
import threading
import time
import webbrowser
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from posta_automatica import Posta
except Exception:                                  # modulo mancante: il resto del servizio funziona lo stesso
    Posta = None

try:
    from licenza import Licenza
except Exception:
    Licenza = None

try:
    from aggiornamenti import Aggiornamenti
except Exception:
    Aggiornamenti = None

QUI = os.path.dirname(os.path.abspath(__file__))
RADICE = os.path.dirname(QUI)                                 # es. C:\Assistenza
APP = os.path.join(RADICE, "app")
ESPORTAZIONI = os.path.join(RADICE, "export_levante")


AGG = None                                                    # aggiornamenti.py: controllo e installazione delle versioni nuove
LICENZA = None                                                # licenza.py: prova di 30 giorni, poi serve la chiave
BACKUP = os.path.join(RADICE, "backup")                       # copie automatiche dei dati dell'app (una al giorno, le ultime 14)


def licenza_ok():
    """Vero se si puo' usare l'ufficio (licenza valida o prova in corso)."""
    try:
        return LICENZA is None or bool(LICENZA.stato().get("ok"))
    except Exception:
        return True


def nome_backup_valido(n):
    import re
    return bool(re.match(r"^Backup_\d{4}-\d{2}-\d{2}\.json$", n or ""))


def salva_backup(testo):
    os.makedirs(BACKUP, exist_ok=True)
    nome = "Backup_%s.json" % datetime.date.today().isoformat()
    p = os.path.join(BACKUP, nome)
    with open(p + ".tmp", "w", encoding="utf-8") as f:
        f.write(testo)
    os.replace(p + ".tmp", p)
    vecchi = sorted(n for n in os.listdir(BACKUP) if nome_backup_valido(n))
    for n in vecchi[:-14]:
        try:
            os.remove(os.path.join(BACKUP, n))
        except OSError:
            pass
    return nome


def elenco_backup():
    try:
        out = []
        for n in sorted((x for x in os.listdir(BACKUP) if nome_backup_valido(x)), reverse=True):
            q = os.path.join(BACKUP, n)
            out.append({"nome": n, "dimensione": os.path.getsize(q), "quando": datetime.datetime.fromtimestamp(os.path.getmtime(q)).isoformat()})
        return out
    except OSError:
        return []


POSTA = None                                                  # ricezione automatica della posta dei tecnici (posta_automatica.py)
STATO = {"in_corso": False, "esito": "", "fine": ""}
BLOCCO = threading.Lock()


def lancia_esportazione():
    """Lancia esporta_levante.py (solo lettura su Levante) e tiene traccia dell'esito. Ritorna False se ne sta gia' girando una."""
    with BLOCCO:
        if STATO["in_corso"]:
            return False
        STATO.update(in_corso=True, esito="", fine="")

    def corri():
        esito = "ok"
        try:
            log = os.path.join(RADICE, "log")
            os.makedirs(log, exist_ok=True)
            env = dict(os.environ, ASSISTENZA_SILENZIOSO="1")
            flag = 0x08000000 if os.name == "nt" else 0                       # CREATE_NO_WINDOW
            with open(os.path.join(log, "ultima_esportazione.txt"), "wb") as f:
                r = subprocess.run([sys.executable, "-X", "utf8", os.path.join(QUI, "esporta_levante.py")], cwd=RADICE, env=env,
                                   stdout=f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, timeout=900, creationflags=flag)
            if r.returncode != 0:
                esito = "errore"
        except Exception as e:
            esito = "errore: %s" % e
        STATO.update(in_corso=False, esito=esito, fine=datetime.datetime.now().isoformat())

    threading.Thread(target=corri, daemon=True).start()
    return True


# ---- esportazione automatica: l'ufficio non deve premere niente, l'agenda dei tecnici e' sempre aggiornata
CONF_AUTO = {"minuti": 15, "dalle": "06:30", "alle": "20:30", "domenica": False, "worker": True}   # minuti = 0: spenta
AUTO = {"ultimo": 0.0}


def conf_auto_path():
    return os.path.join(RADICE, "servizio.json")


def leggi_conf_auto():
    c = dict(CONF_AUTO)
    try:
        with open(conf_auto_path(), encoding="utf-8") as f:
            c.update(json.load(f))
    except Exception:
        pass
    return c


def salva_conf_auto(nuova):
    c = leggi_conf_auto()
    if "minuti" in nuova:
        try:
            c["minuti"] = max(0, min(1440, int(nuova["minuti"])))
        except Exception:
            pass
    for k in ("dalle", "alle"):
        if isinstance(nuova.get(k), str) and len(nuova[k]) == 5 and nuova[k][2] == ":":
            c[k] = nuova[k]
    if "domenica" in nuova:
        c["domenica"] = bool(nuova["domenica"])
    if "worker" in nuova:
        c["worker"] = bool(nuova["worker"])
    try:
        os.makedirs(RADICE, exist_ok=True)
        with open(conf_auto_path(), "w", encoding="utf-8") as f:
            json.dump(c, f, indent=1)
    except Exception:
        pass
    return c


def in_orario(c, adesso=None):
    a = adesso or datetime.datetime.now()
    if a.weekday() == 6 and not c.get("domenica"):
        return False
    d, al, ora = c.get("dalle", "00:00"), c.get("alle", "23:59"), a.strftime("%H:%M")
    if d <= al:
        return d <= ora <= al
    return ora >= d or ora <= al          # fascia a cavallo della mezzanotte


def ultima_esportazione_ts():
    z = ultimo_zip()
    try:
        return os.path.getmtime(z) if z else 0.0
    except OSError:
        return 0.0


def prossima_auto(c):
    if not c.get("minuti"):
        return None
    base = max(AUTO["ultimo"], ultima_esportazione_ts())
    return base + c["minuti"] * 60


def ciclo_auto():
    time.sleep(4)
    while True:
        try:
            c = leggi_conf_auto()
            pr = prossima_auto(c)
            if pr is not None and time.time() >= pr and in_orario(c) and not STATO["in_corso"] and licenza_ok():
                AUTO["ultimo"] = time.time()
                lancia_esportazione()
        except Exception:
            pass
        time.sleep(20)


def ultimo_zip():
    z = sorted(glob.glob(os.path.join(ESPORTAZIONI, "Esportazione_*.zip")))
    return z[-1] if z else None



# ---------------------------------------------------------------- LAVORATORE INVISIBILE
# Lettura della posta dei tecnici, invio serale delle agende e copie di sicurezza sono fatti dall'app stessa.
# Perche' girino anche con il browser chiuso, il servizio apre da solo una copia INVISIBILE dell'app
# (Edge o Chrome senza finestra, con un profilo suo in <radice>\worker-profilo). Se non parte, o se
# l'utente lo spegne, i lavori restano a carico dell'app aperta sul PC server, come prima.
WORKER = {"proc": None, "battito": 0.0, "avviato": 0.0, "browser": "", "stato": "spento", "tentativi": 0, "prossimo": 0.0}
SENZA_WORKER = False
BLOCCO_WORKER = threading.Lock()


def profilo_worker():
    return os.path.join(RADICE, "worker-profilo")


def trova_browser():
    cand = []
    e = os.environ.get("ASSISTENZA_BROWSER")
    if e:
        cand.append(e)
    if os.name == "nt":
        for var in ("ProgramFiles(x86)", "ProgramFiles", "LocalAppData"):
            b = os.environ.get(var)
            if b:
                cand.append(os.path.join(b, "Microsoft", "Edge", "Application", "msedge.exe"))
        for var in ("ProgramFiles", "ProgramFiles(x86)", "LocalAppData"):
            b = os.environ.get(var)
            if b:
                cand.append(os.path.join(b, "Google", "Chrome", "Application", "chrome.exe"))
    else:
        for n in ("chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "microsoft-edge"):
            w = shutil.which(n)
            if w:
                cand.append(w)
        cand.append("/opt/pw-browsers/chromium")
    for c in cand:
        if c and os.path.isfile(c):
            return c
    return ""


def argomenti_worker(browser, nuovo=True):
    a = [browser, "--headless=new" if nuovo else "--headless", "--user-data-dir=" + profilo_worker(), "--no-first-run",
         "--no-default-browser-check", "--disable-gpu", "--disable-extensions", "--disable-sync", "--mute-audio",
         "--disable-background-timer-throttling", "--disable-renderer-backgrounding", "--disable-backgrounding-occluded-windows",
         "--disable-features=CalculateNativeWinOcclusion", "--window-size=1280,900"]
    if os.name != "nt" and hasattr(os, "geteuid") and os.geteuid() == 0:
        a.insert(1, "--no-sandbox")
    a.append("http://127.0.0.1:%d/index.html?worker=1" % PORTA)
    return a


def uccidi_albero(pid):
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           creationflags=0x08000000, timeout=20)
        else:
            try:
                os.killpg(os.getpgid(pid), signal.SIGTERM)
            except Exception:
                os.kill(pid, signal.SIGTERM)
            for _ in range(30):
                time.sleep(0.1)
                try:
                    os.kill(pid, 0)
                except OSError:
                    return
            try:
                os.killpg(os.getpgid(pid), signal.SIGKILL)
            except Exception:
                pass
    except Exception:
        pass


def ferma_worker():
    with BLOCCO_WORKER:
        p = WORKER["proc"]
        WORKER["proc"] = None
    if p is not None and p.poll() is None:
        uccidi_albero(p.pid)
        try:
            p.wait(timeout=5)
        except Exception:
            pass


def pulisci_orfani():
    """Un browser invisibile rimasto acceso da un servizio chiuso male terrebbe bloccato il profilo: lo chiudo."""
    marca = "worker-profilo"
    try:
        if os.name == "nt":
            subprocess.run(["powershell", "-NoProfile", "-Command",
                            "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*%s*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" % marca],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=0x08000000, timeout=40)
        else:
            mio = os.getpid()
            for d in os.listdir("/proc"):
                if d.isdigit() and int(d) != mio:
                    try:
                        with open("/proc/%s/cmdline" % d, "rb") as f:
                            if marca.encode() in f.read():
                                os.kill(int(d), signal.SIGKILL)
                    except Exception:
                        pass
    except Exception:
        pass


def avvia_worker(browser):
    os.makedirs(profilo_worker(), exist_ok=True)
    kw = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
    if os.name == "nt":
        kw["creationflags"] = 0x08000000 | 0x00000200            # senza finestra, in un gruppo suo
    else:
        kw["start_new_session"] = True
    p = subprocess.Popen(argomenti_worker(browser), **kw)
    time.sleep(3)
    if p.poll() is not None:                                      # Edge/Chrome piu' vecchi: provo la modalita' headless classica
        p = subprocess.Popen(argomenti_worker(browser, nuovo=False), **kw)
    with BLOCCO_WORKER:
        WORKER.update(proc=p, avviato=time.time(), browser=browser)


def passo_worker():
    c = leggi_conf_auto()
    voluto = bool(c.get("worker", True)) and not SENZA_WORKER
    p = WORKER["proc"]
    vivo = p is not None and p.poll() is None
    adesso = time.time()
    if not voluto:
        if vivo:
            ferma_worker()
        WORKER["stato"] = "spento"
        return
    if vivo:
        if WORKER["battito"] > WORKER["avviato"]:
            WORKER["tentativi"] = 0
        ref = max(WORKER["battito"], WORKER["avviato"])
        if adesso - ref > 90:                                    # pagina bloccata: la richiudo e riparto
            ferma_worker()
            WORKER["stato"] = "bloccato: riavvio"
            WORKER["tentativi"] += 1
            WORKER["prossimo"] = adesso + 5
        else:
            WORKER["stato"] = "attivo" if adesso - WORKER["battito"] < 45 else "in avvio"
        return
    if p is not None:                                             # si e' chiuso da solo
        WORKER["proc"] = None
        WORKER["tentativi"] += 1
        WORKER["prossimo"] = adesso + min(300, 15 * WORKER["tentativi"])
    if adesso < WORKER["prossimo"]:
        return
    browser = trova_browser()
    if not browser:
        WORKER["stato"] = "non trovo Edge o Chrome"
        WORKER["prossimo"] = adesso + 300
        return
    WORKER["stato"] = "in avvio"
    avvia_worker(browser)


def worker_attivo():
    return time.time() - WORKER["battito"] < 45


def ciclo_worker():
    time.sleep(5)
    pulisci_orfani()
    while True:
        try:
            passo_worker()
        except Exception as e:
            WORKER["stato"] = "errore: %s" % e
        time.sleep(10)


def stato_worker():
    c = leggi_conf_auto()
    voluto = bool(c.get("worker", True)) and not SENZA_WORKER
    p = WORKER["proc"]
    vivo = p is not None and p.poll() is None
    return {"attivo": bool(voluto and vivo and worker_attivo()), "voluto": voluto, "stato": WORKER["stato"],
            "browser": os.path.basename(WORKER["browser"] or "")}


# ---------------------------------------------------------------- PIU' POSTAZIONI IN RETE
# Il servizio gira sul PC "server" (quello con Levante). Gli altri PC aprono l'app nel browser all'indirizzo del server:
# serve la password aziendale (una volta per postazione) e lo stato dell'app (interventi ricevuti, invii, impostazioni)
# e' condiviso dal server, cosi' tutti vedono le stesse cose.
PORTA = 8088
SERVER = None
SOLO_QUESTO_PC = {"/apri-posta", "/apri-cartella", "/posta-allegato-mostra", "/licenza-attiva", "/posta-config", "/servizio-config", "/rete-config", "/backup-salva", "/worker-battito", "/posta-prova", "/posta-smtp-prova", "/aggiorna-config", "/aggiorna-controlla", "/aggiorna-installa", "/aggiorna-indietro"}
CHIAVI_CONDIVISE = ("ass_posta", "ass_inviati", "ass_auto_inv", "ass_impostazioni")
DURATA_SESSIONE = 30 * 86400
BLOCCO_RETE = threading.Lock()
SESSIONI = {}                                                 # sha256(token) -> scadenza
TENTATIVI = {}                                                # ip -> [errori, bloccato fino a]
STATO_COND = {"rev": 0, "chiavi": {}}                         # chiavi: nome -> {"rev": n, "v": valore}
CLAIM = {}


def leggi_rete():
    r = leggi_conf_auto().get("rete")
    return r if isinstance(r, dict) else {}


def salva_rete(nuova):
    c = leggi_conf_auto()
    c["rete"] = nuova
    os.makedirs(RADICE, exist_ok=True)
    with open(conf_auto_path(), "w", encoding="utf-8") as f:
        json.dump(c, f, indent=1)


def hash_password(pw, sale_hex):
    return hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(sale_hex), 200000).hex()


def imposta_password(pw):
    sale = secrets.token_hex(16)
    return {"sale": sale, "hash": hash_password(pw, sale)}


def password_giusta(pw):
    r = leggi_rete()
    if not r.get("hash") or not r.get("sale"):
        return False
    return hmac.compare_digest(hash_password(pw or "", r["sale"]), r["hash"])


def sessioni_path():
    return os.path.join(RADICE, "sessioni.json")


def carica_sessioni():
    try:
        with open(sessioni_path(), encoding="utf-8") as f:
            d = json.load(f)
        ora = time.time()
        SESSIONI.update({k: v for k, v in d.items() if isinstance(v, (int, float)) and v > ora})
    except Exception:
        pass


def salva_sessioni():
    try:
        with open(sessioni_path(), "w", encoding="utf-8") as f:
            json.dump(SESSIONI, f)
    except Exception:
        pass


def nuova_sessione():
    t = secrets.token_urlsafe(32)
    with BLOCCO_RETE:
        ora = time.time()
        for k in [k for k, v in SESSIONI.items() if v < ora]:
            del SESSIONI[k]
        SESSIONI[hashlib.sha256(t.encode()).hexdigest()] = ora + DURATA_SESSIONE
        salva_sessioni()
    return t


def sessione_valida(t):
    if not t:
        return False
    return SESSIONI.get(hashlib.sha256(t.encode()).hexdigest(), 0) > time.time()


def ip_locali():
    out = []
    try:
        t = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        t.connect(("192.0.2.1", 9))                           # nessun pacchetto parte: serve solo a sapere quale scheda si userebbe
        out.append(t.getsockname()[0])
        t.close()
    except Exception:
        pass
    try:
        for r in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            a = r[4][0]
            if not a.startswith("127.") and a not in out:
                out.append(a)
    except Exception:
        pass
    return [a for a in out if not a.startswith("127.") and not a.startswith("169.254.")]


def regola_firewall():
    """Prova ad aprire la porta nel firewall di Windows (serve essere amministratori: se non riesce, lo fa Abilita_rete.bat)."""
    if os.name != "nt":
        return False
    try:
        r = subprocess.run(["netsh", "advfirewall", "firewall", "add", "rule", "name=Assistenza impianti (rete)", "dir=in", "action=allow",
                            "protocol=TCP", "localport=%d" % PORTA, "profile=any", "remoteip=localsubnet"], capture_output=True, timeout=20, creationflags=0x08000000)
        return r.returncode == 0
    except Exception:
        return False


RIAVVIA = threading.Event()


def riavvia_servizio():
    """Ferma il server: e' main() che poi rilancia il programma (cosi' la porta e' gia' libera)."""
    def _r():
        time.sleep(1.2)
        RIAVVIA.set()
        try:
            if SERVER is not None:
                SERVER.shutdown()
        except Exception:
            os._exit(1)
    threading.Thread(target=_r, daemon=True).start()


def rilancia():
    args = [sys.executable] + sys.argv
    if "--senza-browser" not in args:
        args.append("--senza-browser")
    if os.name == "nt":
        subprocess.Popen(args, creationflags=0x08000000 | 0x00000008, close_fds=True)
        return
    os.execv(sys.executable, args)


# ---- stato condiviso
def stato_path():
    return os.path.join(RADICE, "stato", "condiviso.json")


def carica_stato():
    try:
        with open(stato_path(), encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict) and isinstance(d.get("chiavi"), dict):
            STATO_COND.update(rev=int(d.get("rev", 0)), chiavi=d["chiavi"])
    except Exception:
        pass


def salva_stato():
    try:
        os.makedirs(os.path.dirname(stato_path()), exist_ok=True)
        p = stato_path()
        with open(p + ".tmp", "w", encoding="utf-8") as f:
            json.dump(STATO_COND, f, ensure_ascii=False)
        os.replace(p + ".tmp", p)
    except Exception:
        pass


def stato_leggi(da):
    with BLOCCO_RETE:
        return {"ok": True, "rev": STATO_COND["rev"], "chiavi": {k: v for k, v in STATO_COND["chiavi"].items() if v.get("rev", 0) > da}}


def stato_scrivi(chiave, valore, base):
    if chiave not in CHIAVI_CONDIVISE:
        return {"ok": False, "errore": "chiave non consentita"}
    with BLOCCO_RETE:
        att = STATO_COND["chiavi"].get(chiave)
        if att and att.get("rev", 0) != base:
            return {"ok": False, "conflitto": True, "corrente": att}
        STATO_COND["rev"] += 1
        STATO_COND["chiavi"][chiave] = {"rev": STATO_COND["rev"], "v": valore}
        salva_stato()
        return {"ok": True, "rev": STATO_COND["rev"], "chiave_rev": STATO_COND["rev"]}


def claim(nome, secondi):
    """Un solo PC alla volta fa certe cose (per esempio l'invio automatico delle mail ai tecnici)."""
    with BLOCCO_RETE:
        ora = time.time()
        if CLAIM.get(nome, 0) > ora:
            return False
        CLAIM[nome] = ora + max(5, min(3600, int(secondi)))
        return True


class Gestore(http.server.SimpleHTTPRequestHandler):
    extensions_map = dict(http.server.SimpleHTTPRequestHandler.extensions_map)
    extensions_map.update({".js": "text/javascript", ".html": "text/html; charset=utf-8", ".json": "application/json",
                           ".webmanifest": "application/manifest+json", ".svg": "image/svg+xml", ".png": "image/png"})

    def __init__(self, *a, **kw):
        super().__init__(*a, directory=APP, **kw)

    def log_message(self, *a):
        pass

    def _no_cache(self):
        self.send_header("Cache-Control", "no-store")

    def _json(self, codice, oggetto):
        corpo = json.dumps(oggetto).encode("utf-8")
        self.send_response(codice)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(corpo)))
        self._no_cache()
        self.end_headers()
        self.wfile.write(corpo)

    def _locale(self):
        host = (self.headers.get("Host") or "").split(":")[0].lower()
        return self.client_address[0] in ("127.0.0.1", "::1") and host in ("localhost", "127.0.0.1")

    def _cookie(self):
        try:
            c = http.cookies.SimpleCookie(self.headers.get("Cookie") or "")
            return c["ass_sess"].value if "ass_sess" in c else ""
        except Exception:
            return ""

    def _autorizzato(self):
        """Questo PC (localhost) oppure, se la rete e' attiva, una postazione che ha inserito la password."""
        if self._locale():
            return True
        return bool(leggi_rete().get("attiva")) and sessione_valida(self._cookie())

    def _non_autorizzato(self):
        self._json(401, {"ok": False, "login": True, "rete": bool(leggi_rete().get("attiva"))})

    def _accesso(self):
        ip = self.client_address[0]
        with BLOCCO_RETE:
            t = TENTATIVI.get(ip, [0, 0])
            if t[1] > time.time():
                self._json(429, {"ok": False, "errore": "Troppi tentativi: riprova tra qualche minuto."})
                return
        if not leggi_rete().get("attiva"):
            self._json(403, {"ok": False, "errore": "Accesso da rete non attivo."})
            return
        pw = str(self._corpo_json(2000).get("password", ""))
        if password_giusta(pw):
            with BLOCCO_RETE:
                TENTATIVI.pop(ip, None)
            tok = nuova_sessione()
            corpo = json.dumps({"ok": True}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(corpo)))
            self.send_header("Set-Cookie", "ass_sess=%s; Path=/; HttpOnly; SameSite=Strict; Max-Age=%d" % (tok, DURATA_SESSIONE))
            self._no_cache()
            self.end_headers()
            self.wfile.write(corpo)
        else:
            with BLOCCO_RETE:
                t = TENTATIVI.get(ip, [0, 0])
                t[0] += 1
                if t[0] >= 5:
                    t = [0, time.time() + 300]
                TENTATIVI[ip] = t
            time.sleep(0.6)
            self._json(403, {"ok": False, "errore": "Password errata."})

    def _rete_stato(self):
        r = leggi_rete()
        return {"ok": True, "attiva": bool(r.get("attiva")), "password": bool(r.get("hash")), "porta": PORTA,
                "nome": socket.gethostname(), "ip": ip_locali(), "locale": self._locale()}

    def _rete_config(self):
        b = self._corpo_json(5000)
        r = dict(leggi_rete())
        vecchia = bool(r.get("attiva"))
        pw = str(b.get("password") or "")
        if pw:
            if len(pw) < 6:
                self._json(400, {"ok": False, "errore": "La password deve avere almeno 6 caratteri."})
                return
            r.update(imposta_password(pw))
            with BLOCCO_RETE:
                SESSIONI.clear()
                salva_sessioni()
        attiva = bool(b.get("attiva"))
        if attiva and not r.get("hash"):
            self._json(400, {"ok": False, "errore": "Scegli prima una password per le postazioni."})
            return
        r["attiva"] = attiva
        salva_rete(r)
        fw = regola_firewall() if attiva else None
        riavvio = (attiva != vecchia)
        if riavvio:
            riavvia_servizio()
        self._json(200, {"ok": True, "attiva": attiva, "firewall": fw, "riavvio": riavvio, "ip": ip_locali(), "porta": PORTA})

    def _corpo_json(self, massimo=100000):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            return json.loads(self.rfile.read(n).decode("utf-8")) if 0 < n < massimo else {}
        except Exception:
            return {}

    def do_POST(self):
        # Comandi (esporta, apri cartella): solo da questo PC, solo dall'app (intestazione X-Assistenza: una pagina web qualunque non la puo' inviare)
        if self.headers.get("X-Assistenza") != "1":
            self._json(403, {"ok": False, "errore": "non consentito"})
            return
        p = self.path.split("?")[0]
        if p == "/accesso":
            self._accesso()
            return
        if p in SOLO_QUESTO_PC and not self._locale():
            self._json(403, {"ok": False, "errore": "Questa operazione si fa solo dal PC server."})
            return
        if not self._autorizzato():
            self._non_autorizzato()
            return
        if p == "/rete-config":
            self._rete_config()
            return
        if p == "/stato-scrivi":
            b = self._corpo_json(40 * 1024 * 1024)
            self._json(200, stato_scrivi(str(b.get("chiave", "")), b.get("valore"), int(b.get("base") or 0)))
            return
        if p == "/stato-claim":
            b = self._corpo_json(2000)
            self._json(200, {"ok": True, "preso": claim(str(b.get("nome", ""))[:40], b.get("secondi") or 60)})
            return
        if p == "/licenza-attiva":
            self._json(200, LICENZA.attiva(str(self._corpo_json(20000).get("chiave", ""))) if LICENZA else {"ok": False, "messaggio": "Licenza non disponibile."})
        elif p.startswith("/aggiorna-") and AGG is None:
            self._json(501, {"ok": False, "messaggio": "Il modulo degli aggiornamenti non e' installato."})
        elif p == "/aggiorna-config":
            AGG.salva_config(self._corpo_json(5000))
            self._json(200, AGG.stato())
        elif p == "/aggiorna-controlla":
            self._json(200, AGG.controlla())
        elif p == "/aggiorna-installa":
            self._json(200, {"ok": AGG.in_background(AGG.installa, sys.argv)})
        elif p == "/aggiorna-indietro":
            self._json(200, {"ok": AGG.in_background(AGG.torna_indietro, sys.argv)})
        elif p == "/worker-battito":
            WORKER["battito"] = time.time()
            self._json(200, {"ok": True})
        elif p == "/backup-salva":
            try:
                t = self.rfile.read(int(self.headers.get("Content-Length") or 0)).decode("utf-8") if 0 < int(self.headers.get("Content-Length") or 0) < 40 * 1024 * 1024 else ""
                json.loads(t)
                self._json(200, {"ok": True, "nome": salva_backup(t)})
            except Exception as e:
                self._json(400, {"ok": False, "errore": str(e)})
        elif p in ("/esporta", "/posta-invia") and not licenza_ok():
            self._json(402, {"ok": False, "licenza": False, "messaggio": "Licenza scaduta: inserisci la chiave in Impostazioni > Licenza."})
        elif p == "/esporta":
            self._json(200, {"ok": True, "avviata": lancia_esportazione()})
        elif p == "/posta-archivia" and POSTA is not None:
            self._json(200, POSTA.archivia(self._corpo_json().get("nomi") or []))
        elif p.startswith("/posta-") and POSTA is None:
            self._json(501, {"ok": False, "errore": "modulo posta non installato"})
        elif p == "/posta-config":
            try:
                POSTA.salva_config(self._corpo_json())
                self._json(200, {"ok": True, "config": POSTA.config_pubblica()})
            except Exception as e:
                self._json(500, {"ok": False, "errore": str(e)})
        elif p == "/posta-prova":
            self._json(200, POSTA.esegui(solo_prova=True))
        elif p == "/servizio-config":
            self._json(200, {"ok": True, "auto": salva_conf_auto(self._corpo_json())})
        elif p == "/posta-smtp-prova":
            self._json(200, POSTA.prova_smtp())
        elif p == "/posta-invia":
            b = self._corpo_json(60 * 1024 * 1024)
            self._json(200, POSTA.invia_mail(b.get("a"), b.get("oggetto"), b.get("testo"), b.get("allegati")))
        elif p == "/posta-controlla":
            self._json(200, POSTA.esegui())
        elif p == "/posta-allegato-salva":
            b = self._corpo_json(80 * 1024 * 1024)
            try:
                ok = POSTA.salva_allegato(b.get("nome", ""), base64.b64decode(b.get("b64", "")))
            except Exception:
                ok = False
            self._json(200, {"ok": ok})
        elif p == "/posta-allegato-mostra":
            self._json(200, {"ok": POSTA.mostra_allegato(str(self._corpo_json().get("nome", "")))})
        elif p == "/posta-azzera-visti":
            self._json(200, {"ok": POSTA.azzera_visti()})
        elif p == "/posta-fatto":
            self._json(200, {"ok": POSTA.fatto(str(self._corpo_json().get("nome", "")))})
        elif p == "/apri-posta":
            try:
                if os.name == "nt":
                    os.startfile(POSTA.arrivo if POSTA else RADICE)
                self._json(200, {"ok": True})
            except Exception as e:
                self._json(500, {"ok": False, "errore": str(e)})
        elif p == "/apri-cartella":
            try:
                os.makedirs(ESPORTAZIONI, exist_ok=True)
                if os.name == "nt":
                    os.startfile(ESPORTAZIONI)
                self._json(200, {"ok": True})
            except Exception as e:
                self._json(500, {"ok": False, "errore": str(e)})
        else:
            self._json(404, {"ok": False})

    def do_GET(self):
        p = self.path.split("?")[0]
        dati_protetti = (p in ("/licenza-stato", "/servizio-stato", "/aggiorna-stato", "/ultima.json", "/ultima.zip", "/rete-stato", "/stato-leggi")
                         or p.startswith("/posta-"))
        if dati_protetti and not self._autorizzato():
            self._non_autorizzato()
            return
        if p == "/rete-stato":
            self._json(200, self._rete_stato())
            return
        if p == "/stato-leggi":
            try:
                da = int((parse_qs(urlparse(self.path).query).get("da") or ["0"])[0])
            except Exception:
                da = 0
            self._json(200, stato_leggi(da))
            return
        if p == "/aggiorna-stato":
            self._json(200, AGG.stato() if AGG else {"ok": False, "versione": "", "avviato": 0})
            return
        if p == "/licenza-stato":
            self._json(200, LICENZA.stato() if LICENZA else {"ok": True, "stato": "nessuna", "messaggio": ""})
            return
        if p == "/backup-elenco" and self._locale():
            self._json(200, {"file": elenco_backup()})
            return
        if p == "/backup-file" and self._locale():
            n = (parse_qs(urlparse(self.path).query).get("nome") or [""])[0]
            q = os.path.join(BACKUP, n)
            if not nome_backup_valido(n) or not os.path.isfile(q):
                self.send_error(404)
                return
            with open(q, "rb") as f:
                dati = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(dati)))
            self._no_cache()
            self.end_headers()
            self.wfile.write(dati)
            return
        if p == "/servizio-stato":
            c = leggi_conf_auto(); pr = prossima_auto(c)
            c = {k: v for k, v in c.items() if k != "rete"}
            self._json(200, dict(STATO, servizio=True, worker=stato_worker(), posta=POSTA is not None, rete=bool(leggi_rete().get("attiva")), remoto=not self._locale(), auto=dict(c, in_orario=in_orario(c), prossima=(datetime.datetime.fromtimestamp(pr).isoformat() if pr else ""))))
            return
        if p.startswith("/posta-"):
            if POSTA is None:
                self._json(501, {"ok": False})
                return
            if p == "/posta-stato":
                self._json(200, POSTA.stato())
            elif p == "/posta-elenco":
                self._json(200, {"file": POSTA.elenco()})
            elif p == "/posta-allegati":
                self._json(200, {"file": POSTA.elenco_allegati()})
            elif p == "/posta-allegato":
                perc = POSTA.percorso_allegato((parse_qs(urlparse(self.path).query).get("nome") or [""])[0])
                if not perc:
                    self.send_error(404)
                    return
                with open(perc, "rb") as f:
                    dati = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/pdf")
                self.send_header("Content-Length", str(len(dati)))
                self.send_header("Content-Disposition", 'inline; filename="%s"' % os.path.basename(perc).encode("ascii", "replace").decode("ascii").replace('"', ""))
                self._no_cache()
                self.end_headers()
                self.wfile.write(dati)
            elif p == "/posta-file":
                dati = POSTA.leggi((parse_qs(urlparse(self.path).query).get("nome") or [""])[0])
                if dati is None:
                    self.send_error(404)
                    return
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Length", str(len(dati)))
                self._no_cache()
                self.end_headers()
                self.wfile.write(dati)
            else:
                self._json(404, {"ok": False})
            return
        if p == "/ultima.json":
            z = ultimo_zip()
            corpo = json.dumps({"nome": os.path.basename(z), "dimensione": os.path.getsize(z),
                                "quando": datetime.datetime.fromtimestamp(os.path.getmtime(z)).isoformat()} if z else {"nome": ""}).encode("utf-8")
            self.send_response(200 if z else 404)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(corpo)))
            self._no_cache()
            self.end_headers()
            self.wfile.write(corpo)
            return
        if p == "/ultima.zip":
            z = ultimo_zip()
            if not z:
                self.send_error(404)
                return
            with open(z, "rb") as f:
                dati = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Length", str(len(dati)))
            self._no_cache()
            self.end_headers()
            self.wfile.write(dati)
            return
        return super().do_GET()


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = (os.name != "nt")        # su Windows SO_REUSEADDR permetterebbe due servizi sulla stessa porta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--porta", type=int, default=8088)
    ap.add_argument("--rete", action="store_true")
    ap.add_argument("--senza-browser", action="store_true")
    ap.add_argument("--senza-worker", action="store_true", help="non aprire la copia invisibile dell'app (lavori automatici solo dall'app aperta)")
    ap.add_argument("--app", default="", help="cartella dell'app (predefinita: ..\\app)")
    ap.add_argument("--esportazioni", default="", help="cartella delle esportazioni (predefinita: ..\\export_levante)")
    o = ap.parse_args()
    global APP, ESPORTAZIONI
    if o.app:
        APP = os.path.abspath(o.app)
    if o.esportazioni:
        ESPORTAZIONI = os.path.abspath(o.esportazioni)
    if not os.path.isfile(os.path.join(APP, "index.html")):
        print("Non trovo l'app in %s (manca index.html)." % APP)
        return 2
    global POSTA, LICENZA, PORTA, SERVER, SENZA_WORKER, AGG
    PORTA = o.porta
    SENZA_WORKER = bool(o.senza_worker)
    carica_sessioni()
    carica_stato()
    if Licenza is not None:
        try:
            LICENZA = Licenza(RADICE, QUI)
        except Exception as e:
            print("Licenza non disponibile: %s" % e)
    if Posta is not None:
        try:
            POSTA = Posta(RADICE)
        except Exception as e:
            print("Posta automatica non disponibile: %s" % e)
    url = "http://localhost:%d/" % o.porta
    try:
        rete_attiva = bool(o.rete or leggi_rete().get("attiva"))
        srv = Server(("0.0.0.0" if rete_attiva else "127.0.0.1", o.porta), Gestore)
        SERVER = srv
    except OSError:
        # porta occupata: il servizio e' gia' acceso, basta aprire l'app
        if not o.senza_browser:
            webbrowser.open(url)
        return 0
    if POSTA is not None:
        POSTA.avvia()
    if Aggiornamenti is not None:
        try:
            AGG = Aggiornamenti(RADICE, QUI, APP, PORTA, riavvia_servizio, lambda: bool(STATO.get("in_corso")))
            AGG.avvia(sys.argv)
        except Exception as e:
            print("Aggiornamenti non disponibili: %s" % e)
    threading.Thread(target=ciclo_auto, daemon=True).start()
    atexit.register(ferma_worker)
    if os.name != "nt":
        def _fine(*a):
            ferma_worker()
            os._exit(0)
        try:
            signal.signal(signal.SIGTERM, _fine)
        except Exception:
            pass
    threading.Thread(target=ciclo_worker, daemon=True).start()
    print("Assistenza impianti - servizio per l'ufficio attivo: %s" % url)
    if rete_attiva:
        print("Raggiungibile anche dagli altri PC: http://%s:%d/" % (socket.gethostname(), o.porta))
    print("Lascia questa finestra aperta (o ridotta a icona). Per spegnere: chiudila.")
    if not o.senza_browser:
        webbrowser.open(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    ferma_worker()
    if RIAVVIA.is_set():
        try:
            srv.server_close()
            time.sleep(0.5)
            rilancia()
        except Exception as e:
            print("Riavvio non riuscito: %s" % e)
    return 0


if __name__ == "__main__":
    sys.exit(main())
