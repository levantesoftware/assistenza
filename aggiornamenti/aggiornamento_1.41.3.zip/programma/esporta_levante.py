#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ESPORTA DA LEVANTE -> CSV per la web app assistenza impianti

Cosa fa
  Si collega al database Firebird di Levante, esegue solo query di lettura (SELECT)
  e salva alcuni file CSV in una cartella. Non scrive nulla nel database.

Come si usa
  La PRIMA volta fai doppio clic su Esporta_Levante.bat: legge da solo da Levante (Param.ini) il server e l'azienda,
  anche su un PC client (il database resta sul PC server). Se non trova Levante chiede server e percorso del .GDB.
  Lo script si ricorda server, database e password nel file config_levante.json (la password e' protetta con l'account Windows:
  non si legge in chiaro e il file copiato su un altro PC o utente non la rivela):
  dalle volte successive basta un doppio clic su Esporta_Levante.bat.
  Per cambiare database, trascina un altro .GDB sul .bat (oppure cancella config_levante.json).
  I file compaiono nella cartella "export_levante/<data>_<ora>/".

File prodotti
  clienti.csv                clienti che hanno impianti o appuntamenti recenti
  impianti.csv               impianti (in Levante: pratiche di tipo A) con ubicazione
  apparecchi.csv             apparecchi di ogni impianto
  operazioni.csv             catalogo delle operazioni (periodicita', date fisse)
  operazioni_pianificate.csv operazioni pianificate su impianto/apparecchio (ULTIMA, PROSSIMA)
  tecnici.csv                tecnici, con l'ID del loro calendario Google
  cantieri.csv               cantieri (pratiche di tipo P) con il segno "visibile su Express Mag"
  dipendenti.csv             dipendenti/operai attivi (senza costi), con l'indice di manodopera
  tipiore.csv                tipi di ore e di spese dei dipendenti
  sottocantieri1..3.csv      sottocantieri dei cantieri (tutte le colonne tranne prezzi e costi); l'app riconosce da sola il legame col cantiere
  appuntamenti.csv           appuntamenti nella finestra di date, con ID evento Google
  operazioni_appuntamento.csv  operazioni da fare dentro ogni appuntamento
  apparecchi_appuntamento.csv  apparecchi selezionati per ogni appuntamento
  storico_interventi.csv     interventi gia' fatti (ultimi anni) con la relazione
  allegati.csv               allegati di efficienza energetica (RCEE) degli appuntamenti
  azienda.csv                dati della tua azienda (impresa manutentrice)
  Esportazione_<data>.zip    tutti i file qui sotto in un unico file (nell'app si sceglie solo questo)
  articoli.csv               articoli segnati come PREFERITO in Levante (codice, descrizione, um, prezzo)
  codici_barre.csv           articoli con codice a barre (per lo scanner dei tecnici), se la colonna viene trovata
  modello_*.json             modelli di stampa degli RCEE, convertiti dalla cartella reports di Levante
  documenti_appuntamenti.csv, documenti_files.json, documenti_diagnosi.txt, cartella documenti   file (pdf, excel...) allegati agli appuntamenti
  scadenze_vista.csv         elenco "pronto da leggere" delle scadenze (utile per controllare)
"""
import base64
import csv
import datetime
import decimal
import json
import os
import re
import sys
import zipfile

# =====================================================================
# CONFIGURAZIONE  (modifica solo questa parte)
# =====================================================================
CONFIG = {
    # "firebirdsql" = driver Python puro, non serve altro (consigliato)
    # "fdb"         = usa la libreria fbclient del sistema (vedi "fb_library")
    "driver": "firebirdsql",

    # Server Firebird. Se Levante e' sullo stesso PC: "localhost".
    # Se e' su un altro PC (server dello studio): il suo nome o indirizzo IP.
    "host": "localhost",
    "port": 3050,

    # Percorso del file .GDB COME LO VEDE IL SERVER (non quello della tua rete).
    # Esempio: r"C:\dcom\Levante\VERA\VERA.GDB"
    "database": r"C:\dcom\Levante\VERA\VERA.GDB",

    # Credenziali Firebird (le stesse con cui Levante si collega).
    "user": "SYSDBA",
    "password": "masterkey",

    "charset": "ISO8859_1",      # codifica del database di Levante

    # Solo per driver "fdb": percorso di fbclient.dll (deve avere la stessa
    # architettura di Python: 32 o 64 bit). Lascia vuoto altrimenti.
    "fb_library": "",

    # Finestra degli appuntamenti da esportare
    "giorni_indietro": 7,        # appuntamenti degli ultimi N giorni
    "giorni_avanti": 60,         # e dei prossimi N giorni
    "anni_storico": 3,           # storico interventi: ultimi N anni

    # Cartella di Levante (quella che contiene la sottocartella "reports"). Lasciala vuota: la trova da sola.
    "cartella_levante": "",

    # True = esporta anche i documenti dell'impianto e del cliente (oltre a quelli allegati all'appuntamento)
    "documenti_impianto": False,

    "cartella_output": "export_levante",
    "separatore": ";",           # separatore dei campi nel CSV
    "bom": False,                # True se vuoi aprire i CSV con Excel (accenti)
}

# =====================================================================
# QUERY (tutte in sola lettura)
# {DAL} {AL} {STORICO} vengono sostituiti con le date calcolate dallo script
# =====================================================================
QUERIES = {}
NON_FATALI = ("chiamate", "cantieri", "dipendenti", "tipiore")

QUERIES["clienti"] = """
SELECT C.CODICE, C.RAGIONESOCIALE, C.NOME, C.COGNOME, C.INDIRIZZO, C.NUMCIVICO,
       C.CAP, C.CITTA, C.PROVINCIA, C.TELEFONO, C.CELLULARE, C.EMAIL, C.PEC, C.COM_EMAIL,
       C.PARTITAIVA, C.CODICEFISCALE
FROM CLIENTI C
WHERE C.CODICE IN (SELECT P.CLIENTE FROM PRATICHE P WHERE P.TIPO = 'A')
   OR C.CODICE IN (SELECT I.CLIENTE FROM IMPEGNI I WHERE I.START_EVENT >= '{DAL}')
ORDER BY C.RAGIONESOCIALE
"""

# Impianto = pratica di tipo 'A'. Per questo tipo l'ubicazione e' nei campi ...IMM
QUERIES["impianti"] = """
SELECT P.ID, P.CODICE, P.DATAAPERTURA, P.DATACHIUSURA, P.CLIENTE, P.RAGSOCCLI,
       P.DESCRIZIONE, P.NOME, P.TIPOIMPIANTO,
       P.INDIRIZZOIMM AS UBICAZ_INDIRIZZO, P.NUMCIVICOIMM AS UBICAZ_NUMCIVICO,
       P.SCALAIMM AS UBICAZ_SCALA, P.PIANOIMM AS UBICAZ_PIANO, P.INTERNOIMM AS UBICAZ_INTERNO,
       P.CAPIMM AS UBICAZ_CAP, P.COMUNEIMM AS UBICAZ_COMUNE,
       P.PROVINCIAIMM AS UBICAZ_PROVINCIA, P.ZONAIMM AS UBICAZ_ZONA,
       P.TELEFONOCLI, P.CELLULARECLI,
       P.RESOURCEID AS TECNICO_ABITUALE,
       P.STATODESCRIZIONE, P.PROXVISITAENTRO,
       P.CONTRATTO_STATO, P.CONTRATTO_TIPO, P.CONTRATTO_NUMERO,
       P.CONTRATTO_VALIDITA_INIZIO, P.CONTRATTO_VALIDITA_FINE,
       P.NOTE
FROM PRATICHE P
WHERE P.TIPO = 'A'
ORDER BY P.ID
"""

QUERIES["apparecchi"] = """
SELECT PA.ID, PA.IDPRATICA, PA.TIPOIMPIANTO, PA.TIPOAPPARECCHIO, PA.COSTRUTTORE,
       PA.MODELLO, PA.MATRICOLA, PA.BREVEDESCRIZIONE, PA.ANNOCOSTRUZIONE,
       PA.POTENZATERMICA, PA.COMBUSTIBILE, PA.UBICAZIONE, PA.DATAINSTALLAZIONE,
       PA.DATACOLLAUDO, PA.GARANZIA_SCADENZA, PA.DISMESSO, PA.DISMESSO_DATA,
       PA.CODICECATASTO
FROM PRATAPPARECCHI PA
WHERE PA.IDPRATICA IN (SELECT P.ID FROM PRATICHE P WHERE P.TIPO = 'A')
ORDER BY PA.IDPRATICA, PA.ID
"""

QUERIES["operazioni"] = """
SELECT O.CODICE, O.DESCRIZIONE, O.TIPO, O.PERIODICITA, O.TIPOPERIODICITA,
       O.MINUTIPREVISTI, O.GG_AUTOSEL,
       O.DATAFISSA1, O.DATAFISSA2, O.DATAFISSA3, O.DATAFISSA4, O.DATAFISSA5, O.DATAFISSA6,
       O.DATAFISSA7, O.DATAFISSA8, O.DATAFISSA9, O.DATAFISSA10, O.DATAFISSA11, O.DATAFISSA12,
       O.NOTE
FROM OP O
ORDER BY O.CODICE
"""

# IDAPPARECCHIOPRAT vuoto o 0 = operazione generica sull'impianto (non su un apparecchio)
QUERIES["operazioni_pianificate"] = """
SELECT OP.ID, OP.IDPRATICA, OP.IDAPPARECCHIOPRAT, OP.IDOP, OP.DESCRIZIONE,
       OP.PERIODICITA, OP.TIPOPERIODICITA, OP.MINUTIPREVISTI, OP.GG_AUTOSEL,
       OP.ULTIMA, OP.PROSSIMA,
       OP.DATAFISSA1, OP.DATAFISSA2, OP.DATAFISSA3, OP.DATAFISSA4, OP.DATAFISSA5, OP.DATAFISSA6,
       OP.DATAFISSA7, OP.DATAFISSA8, OP.DATAFISSA9, OP.DATAFISSA10, OP.DATAFISSA11, OP.DATAFISSA12,
       OP.NOTE
FROM OPPRATICA OP
WHERE OP.IDPRATICA IN (SELECT P.ID FROM PRATICHE P WHERE P.TIPO = 'A')
ORDER BY OP.PROSSIMA, OP.ID
"""

QUERIES["tecnici"] = """
SELECT T.RESOURCEID, T.RESOURCENAME, T.NOME, T.TELEFONO, T.CELLULARE, T.EMAIL,
       T.GCAL_CALENDAR_ID, T.ABILITATO
FROM TECNICI T
ORDER BY T.RESOURCEID
"""

# Cantieri: in Levante stanno nella tabella PRATICHE (TIPO = 'P'). Li vede l'app solo se il flag "visibile su Express Mag" e' acceso.
# Prezzi, costi e ricarichi del cantiere NON vengono esportati.
QUERIES["cantieri"] = """
SELECT P.ID, P.CODICE, P.NOME, P.DESCRIZIONE, P.DATAAPERTURA, P.DATACHIUSURA, P.CLIENTE, P.RAGSOCCLI,
       P.INDIRIZZOIMM, P.NUMCIVICOIMM, P.CAPIMM, P.COMUNEIMM, P.PROVINCIAIMM, P.CATEGCANT1
FROM PRATICHE P
WHERE P.TIPO = 'P' AND P.VISIBLETOEXPRESSMAG = 'T'
ORDER BY P.CODICE
"""

# Dipendenti/operai: tutti quelli abilitati (anche chi non e' in agenda). Costi orari e prezzi di vendita NON vengono esportati:
# all'app serve solo il nome e l'indice di manodopera (OPERAINDEX).
QUERIES["dipendenti"] = """
SELECT D.CODICE, D.COGNOME, D.NOME, D.EMAIL, D.OPERAINDEX, D.TIPOORE1, D.TIPOORE2, D.TIPOORE3
FROM DIPENDENTI D
WHERE D.ENABLED IS NULL OR D.ENABLED <> 'F'
ORDER BY D.COGNOME, D.NOME
"""

QUERIES["tipiore"] = """
SELECT T.TIPO, T.DESCRIZIONE
FROM TIPIOREDIPENDENTI T
ORDER BY T.TIPO, T.DESCRIZIONE
"""

# Il legame con Google Calendar: IMPEGNI_GCAL.MASTER_ID = IMPEGNI.MASTER_ID
QUERIES["appuntamenti"] = """
SELECT I.ID, I.MASTER_ID, I.TIPOIMPEGNO, I.START_EVENT, I.FINISH_EVENT, I.CAPTION,
       I.LOCATION, I.EVENTMESSAGE, I.RESOURCEID, I.TIPOINTERVENTO, I.FATTO, I.URGENTE,
       I.CLIENTE, I.RAGSOCCLI, I.IDPRATICA, I.MESSAGGI,
       G.EVENT_ID, G.EVENT_CALID
FROM IMPEGNI I
LEFT JOIN IMPEGNI_GCAL G ON G.MASTER_ID = I.MASTER_ID
WHERE I.START_EVENT >= '{DAL}' AND I.START_EVENT < '{AL}'
ORDER BY I.START_EVENT, I.ID
"""

# Chiamate di assistenza ancora aperte: in Levante sono righe di IMPEGNI con TIPOIMPEGNO = 'Chiamata'
# (quando diventano appuntamento o intervento cambia il tipo, l'ID resta). Spesso non hanno data di inizio
# ne' tecnico, per questo non compaiono nella query "appuntamenti". Solo lettura.
QUERIES["chiamate"] = """
SELECT I.ID, I.MASTER_ID, I.TIPOIMPEGNO, I.DATAORACHIAMATA, I.START_EVENT, I.FINISH_EVENT, I.CAPTION,
       I.LOCATION, I.EVENTMESSAGE, I.RESOURCEID, I.TIPOINTERVENTO, I.FATTO, I.URGENTE,
       I.CLIENTE, I.RAGSOCCLI, I.IDPRATICA, I.MESSAGGI, I.RICHIEDENTE,
       I.TELEFONOCLI, I.CELLULARECLI
FROM IMPEGNI I
WHERE I.TIPOIMPEGNO = 'Chiamata' AND (I.FATTO IS NULL OR I.FATTO <> 'T')
ORDER BY I.DATAORACHIAMATA, I.ID
"""

# OPIMPEGNO.IDIMPEGNO = IMPEGNI.ID
QUERIES["operazioni_appuntamento"] = """
SELECT O.ID, O.IDIMPEGNO, I.MASTER_ID AS IMPEGNO_MASTER_ID, O.IDPRATICA, O.IDOPPRATICA,
       O.IDAPPARECCHIOPRAT, O.IDOP, O.DESCRIZIONE, O.DAEFFETTUARE, O.EFFETTUATA,
       O.MINUTIPREVISTI, O.ULTIMA, O.PROSSIMA
FROM OPIMPEGNO O
JOIN IMPEGNI I ON I.ID = O.IDIMPEGNO
WHERE I.START_EVENT >= '{DAL}' AND I.START_EVENT < '{AL}'
ORDER BY O.IDIMPEGNO, O.ID
"""

QUERIES["apparecchi_appuntamento"] = """
SELECT S.IDIMPEGNO, S.IDAPPARECCHIOPRAT
FROM IMPEGNI_APPSEL S
JOIN IMPEGNI I ON I.ID = S.IDIMPEGNO
WHERE I.START_EVENT >= '{DAL}' AND I.START_EVENT < '{AL}'
ORDER BY S.IDIMPEGNO
"""

QUERIES["storico_interventi"] = """
SELECT I.ID, I.MASTER_ID, I.IDPRATICA, I.RESOURCEID, I.TIPOINTERVENTO,
       I.DATAORAINTERVENTO, I.DATAORAFINEINTERVENTO, I.RELAZIONEINTERVENTO,
       I.OSSERVAZIONI, I.RACCOMANDAZIONI, I.PRESCRIZIONI
FROM IMPEGNI I
WHERE I.TIPOIMPEGNO = 'Intervento'
  AND I.IDPRATICA IN (SELECT P.ID FROM PRATICHE P WHERE P.TIPO = 'A')
  AND I.DATAORAINTERVENTO >= '{STORICO}'
ORDER BY I.IDPRATICA, I.DATAORAINTERVENTO
"""

# Allegato di efficienza energetica (RCEE / allegati F e G): tutti i campi dell'allegato di ogni
# appuntamento. ATTENZIONE: in Levante l'allegato si aggancia con IDIMPEGNO = IMPEGNI.MASTER_ID
# (non IMPEGNI.ID). Aggiungo l'ente dell'impianto e i nomi dei modelli di stampa che usa.
QUERIES["allegati"] = """
SELECT A.*, I.ID AS APPUNTAMENTO_ID, P.ENTE_ID, E.NOME AS ENTE_NOME,
       E.IMP_TERM_ALL_F_STMMOD_FILENAME, E.IMP_TERM_ALL_G_STMMOD_FILENAME,
       E.TERM_RCEE1_STMMOD_FILENAME, E.TERM_RCEE1B_STMMOD_FILENAME, E.FRIGO_RCEE2_STMMOD_FILENAME,
       E.SCAMB_RCEE3_STMMOD_FILENAME, E.COGEN_RCEE4_STMMOD_FILENAME
FROM ALLEGATI_MANUT A
JOIN IMPEGNI I ON I.MASTER_ID = A.IDIMPEGNO
LEFT JOIN PRATICHE P ON P.ID = I.IDPRATICA
LEFT JOIN ENTI_X_ALLEGATI_MANUT E ON E.ID = P.ENTE_ID
WHERE I.START_EVENT >= '{DAL}' AND I.START_EVENT < '{AL}'
ORDER BY I.START_EVENT, A.ID
"""

# Dati della tua azienda (compaiono come "impresa manutentrice" nell'RCEE)
QUERIES["azienda"] = """
SELECT RAGIONESOCIALE, INDIRIZZO, NUMCIVICO, CAP, CITTA, PROVINCIA, TELEFONO, P_IVA, EMAIL
FROM DATIAZIE
"""

# Vista gia' "leggibile": una riga per ogni operazione pianificata
QUERIES["scadenze_vista"] = """
SELECT OP.ID, OP.PROSSIMA, OP.ULTIMA, OP.DESCRIZIONE AS OPERAZIONE,
       OP.PERIODICITA, OP.TIPOPERIODICITA,
       P.ID AS IDIMPIANTO, P.CLIENTE, C.RAGIONESOCIALE,
       P.INDIRIZZOIMM AS UBICAZ_INDIRIZZO, P.NUMCIVICOIMM AS UBICAZ_NUMCIVICO,
       P.COMUNEIMM AS UBICAZ_COMUNE, P.ZONAIMM AS UBICAZ_ZONA,
       PA.COSTRUTTORE, PA.MODELLO, PA.MATRICOLA
FROM OPPRATICA OP
JOIN PRATICHE P ON P.ID = OP.IDPRATICA AND P.TIPO = 'A'
LEFT JOIN CLIENTI C ON C.CODICE = P.CLIENTE
LEFT JOIN PRATAPPARECCHI PA ON PA.ID = OP.IDAPPARECCHIOPRAT
ORDER BY OP.PROSSIMA, OP.ID
"""


# =====================================================================
# Da qui in giu' non serve modificare nulla
# =====================================================================

# =====================================================================
# MODELLI DI STAMPA DELL'RCEE (file .QR2 della cartella Levante\reports)
# Vengono convertiti in file .json che l'app usa per disegnare l'RCEE identico a quello di Levante.
# =====================================================================
MODELLI_VERIFICATI = {"RCEE1_EmiliaRomagna_NoteIntegrate.QR2", "RCEE2_EmiliaRomagna_NoteIntegrate.QR2",
                      "RCEE1B_Lombardia_NoteIntegrate.QR2"}   # confrontati con un PDF stampato da Levante
COLONNA_MODELLO = [("RCEE1B", "TERM_RCEE1B_STMMOD_FILENAME"), ("RCEE1", "TERM_RCEE1_STMMOD_FILENAME"),
                   ("RCEE2", "FRIGO_RCEE2_STMMOD_FILENAME"), ("RCEE3", "SCAMB_RCEE3_STMMOD_FILENAME"),
                   ("RCEE4", "COGEN_RCEE4_STMMOD_FILENAME")]
_U, _X0, _Y0 = 0.28346456, 14.17, 28.35
_COL = {"clBlack":"#000000","clWindowText":"#000000","clBlue":"#0000FF","clRed":"#FF0000","clWhite":"#FFFFFF","clNavy":"#000080",
        "clGray":"#808080","clSilver":"#C0C0C0","clGreen":"#008000","clYellow":"#FFFF00","clBtnFace":"#F0F0F0"}


def _qr2_parse(path):
    righe = open(path, encoding="latin-1").read().replace("\r", "").split("\n")
    pila, oggetti, i = [], [], 0
    while i < len(righe):
        s = righe[i].strip()
        m = re.match(r"object (?:(\w+): )?(\w+)$", s)
        if m:
            o = {"name": m.group(1) or "", "cls": m.group(2), "props": {}}
            pila.append(o); oggetti.append(o)
        elif s == "end":
            if pila: pila.pop()
        elif pila:
            mm = re.match(r"([\w\.]+) =(?: (.*))?$", s)
            if mm:
                k, v = mm.group(1), (mm.group(2) or "")
                if v == "" and i + 1 < len(righe) and righe[i+1].strip().startswith(("'", "#")):
                    i += 1; v = righe[i].strip()
                if v.endswith("(") or (v.startswith("(") and not v.endswith(")")):
                    buf = [v]
                    while i + 1 < len(righe) and not buf[-1].rstrip().endswith(")"):
                        i += 1; buf.append(righe[i].strip())
                    v = " ".join(buf)
                while v.rstrip().endswith("+") and i + 1 < len(righe):
                    i += 1; v = v.rstrip()[:-1].rstrip() + " " + righe[i].strip()
                pila[-1]["props"][k] = v
        i += 1
    return oggetti


def _stringa(v):
    out = ""
    for m in re.finditer(r"'((?:[^']|'')*)'|#(\d+)", v or ""):
        out += m.group(1).replace("''", "'") if m.group(1) is not None else chr(int(m.group(2)))
    return out


def _righe(v):
    out, cur, fine = [], None, 0
    for m in re.finditer(r"'((?:[^']|'')*)'|#(\d+)", v or ""):
        pezzo = m.group(1).replace("''", "'") if m.group(1) is not None else chr(int(m.group(2)))
        tra = (v or "")[fine:m.start()]
        if cur is not None and ("+" in tra or tra == ""):
            cur += pezzo
        else:
            if cur is not None: out.append(cur)
            cur = pezzo
        fine = m.end()
    if cur is not None: out.append(cur)
    return out


def _colore(v, default=None):
    if v is None: return default
    v = v.strip()
    if v in _COL: return _COL[v]
    if re.fullmatch(r"-?\d+", v):
        n = int(v) & 0xFFFFFF
        return "#%02X%02X%02X" % (n & 255, (n >> 8) & 255, (n >> 16) & 255)
    return default


def _box(o):
    m = re.search(r"\(([^)]*)\)", o["props"].get("Size.Values", ""))
    if not m: return None
    h, l, t, w = [float(x) for x in m.group(1).split()[:4]]
    return {"x": round(_X0 + l * _U, 2), "y": round(_Y0 + t * _U, 2), "w": round(w * _U, 2), "h": round(h * _U, 2)}


def _font(p):
    st = p.get("Font.Style", "[]")
    return {"size": float(p.get("FontSize") or abs(int(p.get("Font.Height", "-8"))) * 0.75), "bold": "fsBold" in st,
            "italic": "fsItalic" in st, "underline": "fsUnderline" in st, "name": _stringa(p.get("Font.Name", "'Arial'")),
            "color": _colore(p.get("Font.Color"), "#000000")}


def _sposta_d3d4(items):
    """In molti modelli le righe D3 e D4 (aperture di ventilazione) sono disegnate piu' in basso, sopra al
    blocco E: Levante le riporta sotto D1 e D2 al momento della stampa. Qui si fa lo stesso, solo se
    il modello ha davvero questa disposizione. Spostamento verificato su PDF stampati da Levante."""
    nom = {i["name"]: i for i in items if i["t"] == "label" and i.get("name")}
    d1, d2, d3 = nom.get("D1_SI"), nom.get("D2_SI"), nom.get("D3_SI")
    if not (d1 and d2 and d3):
        return False
    dx = d3["x"] - d1["x"]
    dy = d3["y"] - (d2["y"] + (d2["y"] - d1["y"]))
    if not (8 < dx < 20 and dy > 15):
        return False                                  # disposizione diversa: non tocco niente
    sinistra = d1["x"] + 60                           # solo la colonna di sinistra
    righe_y = [nom[n]["y"] for n in ("D3_SI", "D4_SI") if n in nom and nom[n]["x"] < sinistra]
    caselle = [(i["x"], i["y"]) for i in items if i["t"] == "label" and i.get("name", "")[:3] in ("D3_", "D4_") and i["x"] < sinistra]
    for it in items:
        nome, testo = it.get("name", ""), (it.get("text") or "").strip()
        if it["t"] == "label" and nome[:3] in ("D3_", "D4_") and it["x"] < sinistra:
            it["y"] = round(it["y"] - dy, 2); it["x"] = round(it["x"] - dx, 2)
        elif it["t"] == "label" and it["x"] < 200 and (testo.startswith("Aperture di ventilazione") or testo.startswith("Adeguate dimensioni")) \
                and any(abs(it["y"] - y) < 8 for y in righe_y):
            it["y"] = round(it["y"] - dy, 2)
        elif it["t"] == "shape" and it["shape"] in ("rrect", "rect") and it["w"] < 20 and it["h"] < 20:
            for (cx, cy) in caselle:
                if abs(it["x"] - cx) < 4 and abs(it["y"] - cy) < 4:
                    it["y"] = round(it["y"] - dy, 2); it["x"] = round(it["x"] - dx, 2); break
    return True

def converti_modello(path):
    items = []
    for o in _qr2_parse(path):
        c, p = o["cls"], o["props"]
        if c not in ("TQRDesignLabel", "TQRDesignShape", "TQRDesignDBText", "TQRDesignMemo"): continue
        b = _box(o)
        if not b: continue
        it = dict(b); it["name"] = o["name"]
        al = p.get("Alignment", "taLeftJustify")[2:].replace("LeftJustify", "l").replace("RightJustify", "r").replace("Center", "c")
        if c == "TQRDesignLabel":
            it.update(t="label", text=_stringa(p.get("Caption")), align=al, font=_font(p), wrap=p.get("WordWrap") == "True",
                      enabled=p.get("Enabled") != "False", fill=None if p.get("Transparent", "True") == "True" else _colore(p.get("Color")))
        elif c == "TQRDesignShape":
            it.update(t="shape", shape={"qrsRectangle":"rect","qrsRoundRect":"rrect","qrsHorLine":"hline","qrsVertLine":"vline","qrsCircle":"circle"}.get(p.get("Shape"), "rect"),
                      pen=_colore(p.get("Pen.Color"), "#000000"), dot=p.get("Pen.Style") == "psDot",
                      fill=None if p.get("Brush.Style") == "bsClear" else _colore(p.get("Brush.Color")), enabled=p.get("Enabled") != "False")
        elif c == "TQRDesignDBText":
            it.update(t="db", field=_stringa(p.get("DataField")), align=al, font=_font(p),
                      mask=_stringa(p.get("Mask")) if p.get("Mask") else "", blank0=p.get("BlankIfZero") == "True")
        else:
            it.update(t="memo", lines=_righe(p.get("Lines.Strings")), font=_font(p), align="l")
        items.append(it)
    _sposta_d3d4(items)
    return {"w": 595.28, "h": 841.89, "items": items}


def cerca_cartella_report(cfg):
    base = cfg.get("cartella_levante") or ""
    db = cfg["database"].replace("\\", "/")
    cand = [base] if base else []
    cand += [os.path.dirname(os.path.dirname(db)), os.path.dirname(db), os.path.dirname(os.path.dirname(os.path.dirname(db)))]
    pi = cerca_param_ini(cfg)
    if pi:
        cand.append(os.path.dirname(pi))
    for c in cand:
        for sub in ("reports", "Reports"):
            if c and os.path.isdir(os.path.join(c, sub)):
                return os.path.join(c, sub)
    return None


def esporta_modelli(cartella, cfg):
    """Legge allegati.csv, capisce quali modelli servono e li converte in modello_<nome>.json"""
    p = os.path.join(cartella, "allegati.csv")
    if not os.path.exists(p):
        return
    with open(p, newline="", encoding="utf-8-sig") as f:
        righe = list(csv.DictReader(f, delimiter=cfg["separatore"]))
    nomi = {}
    for r in righe:
        tipo = (r.get("TIPO") or "").upper()
        for sigla, col in COLONNA_MODELLO:
            if tipo.startswith(sigla) and (r.get(col) or "").strip():
                nomi[r[col].strip()] = sigla; break
    if not nomi:
        return
    rep = cerca_cartella_report(cfg)
    if not rep:
        print("  modelli di stampa            cartella 'reports' di Levante non trovata (imposta cartella_levante)")
        return
    for nome, sigla in sorted(nomi.items()):
        qr2 = os.path.join(rep, nome)
        if not os.path.exists(qr2):
            print("  modello %-34s non trovato in %s" % (nome, rep)); continue
        try:
            mod = converti_modello(qr2)
            mod["nome"] = nome; mod["tipo"] = sigla; mod["verificato"] = nome in MODELLI_VERIFICATI
            with open(os.path.join(cartella, "modello_" + re.sub(r"\.QR2$", "", nome, flags=re.I) + ".json"), "w", encoding="utf-8") as f:
                json.dump(mod, f, ensure_ascii=False, separators=(",", ":"))
            print("  modello %-34s ok%s" % (nome, "" if mod["verificato"] else "  (non ancora verificato con un PDF di Levante)"))
        except Exception as e:
            print("  modello %-34s ERRORE: %s" % (nome, e))


# =====================================================================
# DOCUMENTI ALLEGATI ALL'APPUNTAMENTO (pdf, excel, ...) conservati nell'archivio di Levante
# In Levante un file allegato a un appuntamento e' una riga della tabella ALLEGATI con
#   TIPODOC = 'Intervento'  e  NUMDOC = numero dell'appuntamento (il "N." dell'agenda).
# (Verificato su un allegato di prova.) Opzionalmente si possono aggiungere anche i documenti
# dell'impianto e del cliente: imposta "documenti_impianto" a True in CONFIG.
# I file vengono salvati sia nella cartella "documenti" sia in documenti_files.json,
# il file che l'app dell'ufficio legge insieme agli altri per passarli ai tecnici.
# =====================================================================
LIMITE_FILE_MB = 8     # i file piu' grandi non vengono esportati (restano in Levante)
_COLONNE_DOC = """A.NUMPROT, A.REVPROT, A.ANNOPROT, A.TIPODOC, A.NUMDOC, A.CODSOGG, A.CODPRAT, A.DATAPRAT, A.NOTE,
       A.FILE_EXT, A.FILE_NAME, A.LINK, A.CREAZ_OPERATORE, A.CREAZ_DATAORA, A.ULTMOD_DATAORA, I.ID AS APPUNTAMENTO_ID"""
SQL_DOC_APPUNTAMENTO = """
SELECT """ + _COLONNE_DOC + """, 'appuntamento' AS COLLEGAMENTO
FROM IMPEGNI I
JOIN ALLEGATI A ON A.TIPODOC = 'Intervento' AND A.NUMDOC = I.ID
WHERE I.START_EVENT >= '{DAL}' AND I.START_EVENT < '{AL}'
"""
SQL_DOC_IMPIANTO = """
SELECT """ + _COLONNE_DOC + """, 'impianto' AS COLLEGAMENTO
FROM IMPEGNI I
JOIN PRATICHE P ON P.ID = I.IDPRATICA
JOIN ALLEGATI A ON A.CODPRAT = P.CODICE AND A.DATAPRAT = P.DATAAPERTURA
WHERE I.START_EVENT >= '{DAL}' AND I.START_EVENT < '{AL}'
  AND NOT (A.TIPODOC = 'Intervento' AND A.NUMDOC = I.ID)
UNION ALL
SELECT """ + _COLONNE_DOC + """, 'cliente' AS COLLEGAMENTO
FROM IMPEGNI I
JOIN ALLEGATI A ON A.CODSOGG = I.CLIENTE AND A.CODPRAT IS NULL
WHERE I.START_EVENT >= '{DAL}' AND I.START_EVENT < '{AL}'
  AND NOT (A.TIPODOC = 'Intervento' AND A.NUMDOC = I.ID)
"""



# ---- riconoscimento e "scompattamento" dei file salvati da Levante nel database ----
# Levante potrebbe salvare i file compressi (zlib/gzip), con un'intestazione, o codificati: qui si prova a
# capirlo guardando i primi byte, e si registra cosa e' stato fatto in documenti_diagnosi.txt.
_FIRME = [(b"%PDF-", "PDF"), (b"PK\x03\x04", "ZIP/Office (xlsx, docx)"), (b"\xd0\xcf\x11\xe0", "Office 97 (xls, doc)"),
          (b"\x89PNG", "PNG"), (b"\xff\xd8\xff", "JPEG"), (b"GIF8", "GIF"), (b"{\\rtf", "RTF"),
          (b"II*\x00", "TIFF"), (b"MM\x00*", "TIFF"), (b"BM", "BMP")]


def riconosci_formato(d):
    for firma, nome in _FIRME:
        if d[:len(firma)] == firma:
            return nome
    return ""


_ATTESO = {"pdf": "PDF", "png": "PNG", "jpg": "JPEG", "jpeg": "JPEG", "gif": "GIF", "bmp": "BMP", "rtf": "RTF",
           "tif": "TIFF", "tiff": "TIFF", "xlsx": "ZIP", "docx": "ZIP", "pptx": "ZIP", "zip": "ZIP", "xls": "Office 97", "doc": "Office 97"}


def _candidati(dati):
    """Possibili modi in cui Levante puo' aver 'impacchettato' un file: (nome, funzione che lo scompatta)."""
    import base64, gzip, io, zipfile, zlib
    def da_zip():
        z = zipfile.ZipFile(io.BytesIO(dati))
        nomi = [n for n in z.namelist() if not n.endswith("/")]
        if not nomi:
            raise ValueError("zip vuoto")
        return z.read(nomi[0])
    c = [("zip (primo file)", da_zip), ("zlib", lambda: zlib.decompress(dati))]
    for n in (4, 8):
        c.append(("lunghezza(%d byte)+zlib" % n, lambda n=n: zlib.decompress(dati[n:])))
    c += [("gzip", lambda: gzip.decompress(dati)),
          ("deflate grezzo", lambda: zlib.decompressobj(-15).decompress(dati)),
          ("deflate grezzo dopo 4 byte", lambda: zlib.decompressobj(-15).decompress(dati[4:])),
          ("base64", lambda: base64.b64decode(dati, validate=False))]
    return c


def decodifica_file(dati, ext, profondita=0):
    """Ritorna (byte_del_file, descrizione_di_cosa_ho_fatto). Si ferma quando il formato e' quello
    che ci si aspetta dall'estensione (un .pdf deve iniziare con %PDF-)."""
    atteso = _ATTESO.get(ext)
    fmt = riconosci_formato(dati)
    if fmt and (not atteso or fmt.startswith(atteso)):
        return dati, "originale"
    if profondita < 2:
        for nome, f in _candidati(dati):
            try:
                r = f()
            except Exception:
                continue
            if not r:
                continue
            fr = riconosci_formato(r)
            if fr and (not atteso or fr.startswith(atteso)):
                return r, "scompattato (%s)" % nome
            if profondita == 0 and fr is not None and not fr:      # non riconosciuto: provo un secondo livello
                rr, come = decodifica_file(r, ext, profondita + 1)
                if come != "NON RICONOSCIUTO":
                    return rr, "scompattato (%s) + %s" % (nome, come)
    i = dati[:4096].find(b"%PDF-")
    if i > 0 and atteso in (None, "PDF"):
        return dati[i:], "tolti %d byte iniziali" % i
    return dati, "NON RICONOSCIUTO" + ((" (formato rilevato: %s, atteso %s)" % (fmt, atteso)) if fmt and atteso else "")


def _nome_sicuro(t):
    t = re.sub(r"[^A-Za-z0-9._-]+", "_", str(t or "")).strip("._")
    return t[:80] or "file"


def esporta_documenti(con, cartella, cfg, date):
    import base64
    import mimetypes
    sql = SQL_DOC_APPUNTAMENTO + ("UNION ALL" + SQL_DOC_IMPIANTO.replace("\nSELECT", " SELECT", 1) if cfg.get("documenti_impianto") else "")
    for chiave, d in date.items():
        sql = sql.replace(chiave, d)
    cur = con.cursor(); cur.execute(sql)
    colonne = [c[0] for c in cur.description]
    righe = [dict(zip(colonne, r)) for r in cur.fetchall()]
    cur.close()
    if not righe:
        print("  documenti allegati          nessuno per questi appuntamenti")
        return
    cart_file = os.path.join(cartella, "documenti")
    salvati, per_json, diagnosi = {}, [], []
    for r in righe:
        chiave = (r["NUMPROT"], r["REVPROT"], r["ANNOPROT"])
        if chiave in salvati:
            continue
        info = {"FILE_SALVATO": "", "DIMENSIONE": ""}
        try:
            c2 = con.cursor()
            c2.execute("SELECT FILE_BLOB FROM ALLEGATI WHERE NUMPROT = ? AND REVPROT = ? AND ANNOPROT = ?", chiave)
            ris = c2.fetchone(); c2.close()
            dati = ris[0] if ris else None
            if dati is not None and hasattr(dati, "read"):
                dati = dati.read()
            if isinstance(dati, str):
                dati = dati.encode("latin-1", "replace")
            if dati:
                grezzi = dati
                dati, come = decodifica_file(dati, str(r["FILE_EXT"] or "").strip(".").lower())
                diagnosi.append("%-40s byte nel database: %-9d primi byte: %s  -> %s%s" % (
                    str(r["FILE_NAME"] or "")[:40], len(grezzi), grezzi[:16].hex(" "), come,
                    ("  (dopo: %d byte, formato %s)" % (len(dati), riconosci_formato(dati) or "?")) if come != "originale" else
                    "  (formato %s)" % (riconosci_formato(dati) or "?")))
                info["DIMENSIONE"] = str(len(dati))
                if len(dati) <= LIMITE_FILE_MB * 1024 * 1024:
                    os.makedirs(cart_file, exist_ok=True)
                    ext = str(r["FILE_EXT"] or "").strip(".").lower()
                    nome_orig = str(r["FILE_NAME"] or "").strip() or ("documento." + ext if ext else "documento")
                    if ext and not nome_orig.lower().endswith("." + ext):
                        nome_orig += "." + ext
                    nome = "%s-%s_%s_%s" % (r["NUMPROT"], r["REVPROT"], r["ANNOPROT"], _nome_sicuro(nome_orig))
                    with open(os.path.join(cart_file, nome), "wb") as f:
                        f.write(dati)
                    info["FILE_SALVATO"] = nome
                    if _ATTESO.get(ext) and not riconosci_formato(dati).startswith(_ATTESO[ext]):
                        info["FILE_SALVATO"] = nome + "  (ATTENZIONE: il contenuto non corrisponde all'estensione)"
                        print("  ATTENZIONE: %s non ha il formato atteso: potrebbe essere danneggiato" % nome_orig)
                    info["_json"] = {"id": "%s-%s_%s" % chiave, "nome": nome_orig, "ext": ext, "size": len(dati),
                                     "mime": mimetypes.guess_type(nome_orig)[0] or "application/octet-stream",
                                     "b64": base64.b64encode(dati).decode("ascii")}
                else:
                    info["FILE_SALVATO"] = "TROPPO GRANDE (%.1f MB)" % (len(dati) / 1048576.0)
        except Exception as e:
            info["FILE_SALVATO"] = "ERRORE: %s" % e
        salvati[chiave] = info
    with open(os.path.join(cartella, "documenti_appuntamenti.csv"), "w", newline="", encoding="utf-8-sig" if cfg["bom"] else "utf-8") as f:
        w = csv.writer(f, delimiter=cfg["separatore"], quoting=csv.QUOTE_MINIMAL)
        w.writerow(colonne + ["FILE_SALVATO", "DIMENSIONE"])
        for r in righe:
            info = salvati[(r["NUMPROT"], r["REVPROT"], r["ANNOPROT"])]
            w.writerow([valore(r[c]) for c in colonne] + [info["FILE_SALVATO"], info["DIMENSIONE"]])
            j = info.get("_json")
            if j:
                voce = dict(j); voce["appuntamento_id"] = valore(r["APPUNTAMENTO_ID"]); voce["collegamento"] = valore(r["COLLEGAMENTO"]).strip()
                per_json.append(voce)
    with open(os.path.join(cartella, "documenti_diagnosi.txt"), "w", encoding="utf-8") as f:
        f.write("Come sono stati letti i documenti allegati (mandami questo file se qualcuno non si apre):\n\n" + "\n".join(diagnosi) + "\n")
    for riga in diagnosi:
        if "NON RICONOSCIUTO" in riga:
            print("  ATTENZIONE: un documento non e' in un formato riconosciuto (vedi documenti_diagnosi.txt)")
            break
    if per_json:
        with open(os.path.join(cartella, "documenti_files.json"), "w", encoding="utf-8") as f:
            json.dump(per_json, f, ensure_ascii=False, separators=(",", ":"))
    print("  documenti allegati          %d righe, %d file (documenti_files.json + cartella 'documenti')" % (len(righe), len(per_json)))

def connetti(cfg):
    if cfg["driver"] == "fdb":
        import fdb
        if cfg["fb_library"]:
            fdb.load_api(cfg["fb_library"])
        dsn = cfg["database"]
        if cfg["host"]:
            dsn = "%s/%s:%s" % (cfg["host"], cfg["port"], cfg["database"])
        kw = {"dsn": dsn, "charset": cfg["charset"], "sql_dialect": 1}
        if cfg["user"]:
            kw["user"], kw["password"] = cfg["user"], cfg["password"]
        return fdb.connect(**kw)
    import firebirdsql
    return firebirdsql.connect(host=cfg["host"], port=int(cfg["port"]), database=cfg["database"],
                               user=cfg["user"], password=cfg["password"], charset=cfg["charset"])



# =====================================================================
# RICONOSCIMENTO AUTOMATICO DEL SERVER (dalla configurazione di Levante)
# Levante tiene in Param.ini, nella sua cartella, l'indirizzo del server (ServerAddress) e il nome
# dell'azienda aperta (AziendaCorrente). Su un PC client ServerAddress e' l'IP del PC server.
# =====================================================================
CARTELLE_LEVANTE_COMUNI = [r"C:\dcom\Levante", r"C:\Programmi\dcom\Levante", r"C:\Program Files\dcom\Levante",
                           r"C:\Program Files (x86)\dcom\Levante", r"D:\dcom\Levante", r"D:\Programmi\dcom\Levante"]


def _trova_file(cartella, nome):
    """Cerca un file ignorando maiuscole e minuscole."""
    try:
        for f in os.listdir(cartella):
            if f.lower() == nome.lower():
                return os.path.join(cartella, f)
    except OSError:
        pass
    return None


def cerca_param_ini(cfg):
    qui = os.path.dirname(os.path.abspath(__file__))
    cand = [cfg.get("cartella_levante") or "", qui, os.path.dirname(qui)] + CARTELLE_LEVANTE_COMUNI
    for c in cand:
        if c and os.path.isdir(c):
            f = _trova_file(c, "Param.ini")
            if f:
                return f
    return None


def leggi_param_ini(percorso):
    """Ritorna (server, azienda) letti da Param.ini; i valori mancanti sono stringhe vuote."""
    server = azienda = ""
    sezione = ""
    try:
        with open(percorso, encoding="latin-1") as f:
            for riga in f:
                r = riga.strip()
                if r.startswith("[") and r.endswith("]"):
                    sezione = r[1:-1].strip().upper()
                elif "=" in r and sezione == "ARCPATH":
                    k, v = r.split("=", 1)
                    if k.strip().lower() == "serveraddress":
                        server = v.strip()
                    elif k.strip().lower() == "aziendacorrente":
                        azienda = v.strip()
    except OSError:
        pass
    return server, azienda


def èServerLocale(host):
    h = (host or "").strip().lower()
    return h in ("", "localhost", "127.0.0.1", "::1", "(local)", "." ) or h == os.environ.get("COMPUTERNAME", "").lower()


def elenca_database(param):
    """Tutti i file .GDB che stanno nelle sottocartelle della cartella di Levante (una per azienda): [(azienda, percorso)]."""
    base = os.path.dirname(param)
    out = []
    try:
        for sub in sorted(os.listdir(base)):
            d = os.path.join(base, sub)
            if not os.path.isdir(d):
                continue
            for f in sorted(os.listdir(d)):
                if f.lower().endswith(".gdb"):
                    out.append((sub, os.path.join(d, f)))
    except OSError:
        pass
    return out


def proponi_connessione(cfg):
    """Se trova Levante su questo PC propone server e database. Ritorna un dizionario o None."""
    param = cerca_param_ini(cfg)
    if not param:
        return None
    server, azienda = leggi_param_ini(param)
    if not azienda:
        return None
    cartella = os.path.dirname(param)
    locale = èServerLocale(server)
    db_locale = None
    for sub in (azienda, azienda.upper(), azienda.lower()):
        d = os.path.join(cartella, sub)
        if os.path.isdir(d):
            f = _trova_file(d, azienda + ".GDB")
            if f:
                db_locale = f
                break
    if locale:
        if not db_locale:
            return None
        return {"host": "localhost", "database": db_locale, "param": param, "server": server or "questo PC", "azienda": azienda, "indovinato": False}
    # PC client: il database sta sul server; il percorso lo conosce il server, qui si prova lo stesso schema di cartelle
    guess = db_locale or os.path.join(cartella, azienda, azienda + ".GDB")
    return {"host": server, "database": guess, "param": param, "server": server, "azienda": azienda, "indovinato": True}


FILE_MEMORIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config_levante.json")


def proteggi_pwd(testo):
    """Protegge la password con l'account Windows (DPAPI): solo questo utente su questo PC la puo' rileggere."""
    if not testo:
        return ""
    dati = testo.encode("utf-8")
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            class BLOB(ctypes.Structure):
                _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
            b_in = BLOB(len(dati), ctypes.cast(ctypes.create_string_buffer(dati, len(dati)), ctypes.POINTER(ctypes.c_char)))
            b_out = BLOB()
            if ctypes.windll.crypt32.CryptProtectData(ctypes.byref(b_in), "Assistenza", None, None, None, 0, ctypes.byref(b_out)):
                r = ctypes.string_at(b_out.pbData, b_out.cbData)
                ctypes.windll.kernel32.LocalFree(b_out.pbData)
                return "dpapi:" + base64.b64encode(r).decode("ascii")
        except Exception:
            pass
    return "b64:" + base64.b64encode(dati).decode("ascii")      # fuori da Windows: solo offuscata


def svela_pwd(testo):
    """Il contrario. Un valore senza prefisso e' una password scritta in chiaro da una versione precedente: si accetta
    e al prossimo salvataggio viene protetta."""
    if not testo:
        return ""
    try:
        if testo.startswith("dpapi:"):
            if os.name != "nt":
                return ""
            import ctypes
            from ctypes import wintypes

            class BLOB(ctypes.Structure):
                _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
            dati = base64.b64decode(testo[6:])
            b_in = BLOB(len(dati), ctypes.cast(ctypes.create_string_buffer(dati, len(dati)), ctypes.POINTER(ctypes.c_char)))
            b_out = BLOB()
            if ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(b_in), None, None, None, None, 0, ctypes.byref(b_out)):
                r = ctypes.string_at(b_out.pbData, b_out.cbData)
                ctypes.windll.kernel32.LocalFree(b_out.pbData)
                return r.decode("utf-8")
            return ""                                           # file copiato da un altro PC o utente: non si apre
        if testo.startswith("b64:"):
            return base64.b64decode(testo[4:]).decode("utf-8")
    except Exception:
        return ""
    return testo


def leggi_memoria():
    try:
        with open(FILE_MEMORIA, encoding="utf-8") as f:
            m = json.load(f)
    except (OSError, ValueError):
        return {}
    if isinstance(m, dict):
        m["password"] = svela_pwd(m.get("password", ""))
        return m
    return {}


def salva_memoria(cfg):
    try:
        with open(FILE_MEMORIA, "w", encoding="utf-8") as f:
            json.dump({"host": cfg["host"], "database": cfg["database"], "password": proteggi_pwd(cfg["password"])}, f, indent=2)
    except OSError:
        pass


def chiedi_database(cfg):
    """Come si sceglie il database: (1) file .GDB trascinato sul .bat; (2) quello ricordato;
    (3) il riconoscimento automatico da Param.ini di Levante; (4) lo si scrive a mano."""
    memoria = leggi_memoria()
    if len(sys.argv) > 1:                                  # file trascinato sul .bat: nuova scelta
        cfg["database"] = sys.argv[1].strip().strip('"')
        if cfg["database"].startswith("\\\\"):
            print("Attenzione: hai trascinato un percorso di rete (%s)." % cfg["database"])
            print("Se il database sta su un altro PC non serve: apri senza trascinare e lo script lo trova da solo.\n")
        if memoria.get("database") == cfg["database"]:
            cfg["host"] = memoria.get("host", cfg["host"])
            if memoria.get("password"):
                cfg["password"] = memoria["password"]
        return
    if memoria.get("database"):                            # doppio clic: usa quello ricordato
        cfg["database"] = memoria["database"]
        cfg["host"] = memoria.get("host", cfg["host"])
        if memoria.get("password"):
            cfg["password"] = memoria["password"]
        print("Uso il server e il database ricordati (per cambiarli, cancella il file config_levante.json).")
        return
    prop = proponi_connessione(cfg)
    if prop:
        cfg["host"], cfg["database"] = prop["host"], prop["database"]
        cfg["_indovinato"] = prop["indovinato"]
        print("Ho trovato Levante (%s):" % prop["param"])
        print("  azienda: %s   server: %s" % (prop["azienda"], prop["server"]))
        if prop["indovinato"]:
            print("  Il database e' sul server: provo il percorso %s" % prop["database"])
        elenco = elenca_database(prop["param"]) if not prop["indovinato"] else []
        if len(elenco) > 1 and sys.stdin and sys.stdin.isatty():
            print("\nSul PC ci sono questi database (uno per azienda):")
            for i, (az, pth) in enumerate(elenco, 1):
                print("  %d) %s   (%s)%s" % (i, az, pth, "   <- quello proposto" if os.path.normcase(pth) == os.path.normcase(prop["database"]) else ""))
            r = input("Scrivi il numero dell'azienda da usare, oppure premi Invio per usare quella proposta > ").strip()
            if r.isdigit() and 1 <= int(r) <= len(elenco):
                cfg["database"] = elenco[int(r) - 1][1]
                print("Uso: %s" % cfg["database"])
        return
    print("Non ho trovato Levante su questo PC.")
    print("Scrivi l'indirizzo (IP o nome) del PC dove c'e' il database, oppure premi Invio se e' questo PC.")
    h = input("Server > ").strip()
    if h:
        cfg["host"] = h
    print("Ora scrivi il percorso del file .GDB COME LO VEDE IL SERVER (per esempio C:\\dcom\\Levante\\VERA\\VERA.GDB),")
    print("oppure trascina qui il file se il database e' su questo PC, e premi Invio.")
    p = input("> ").strip().strip('"')
    if p:
        cfg["database"] = p


def collega(cfg):
    """Prova a collegarsi; se la password non va la chiede (massimo 3 tentativi)."""
    for tentativo in range(4):
        try:
            return connetti(cfg)
        except Exception as e:
            msg = str(e)
            if re.search(r"password|user name|335544472", msg, re.I) and tentativo < 3:
                print("\nUtente o password di Firebird non accettati.")
                cfg["password"] = input("Scrivi la password di Firebird (di solito: masterkey): ").strip()
                continue
            if "No module named" in msg:
                print("\nManca un componente di Python: %s" % msg)
                print("Apri il prompt dei comandi e scrivi:  pip install firebirdsql passlib")
                sys.exit(1)
            if cfg.get("_indovinato") and not cfg.get("_chiesto") and re.search(r"I/O error|No such file|file|database|335544344|335544734", msg, re.I):
                cfg["_chiesto"] = True
                print("\nNon riesco ad aprire %s sul server %s." % (cfg["database"], cfg["host"]))
                print("Scrivi il percorso del file .GDB COME LO VEDE IL PC SERVER (per esempio C:\\dcom\\Levante\\VERA\\VERA.GDB).")
                print("Lo trovi aprendo Esplora file sul PC server, oppure chiedendo a chi ha installato Levante.")
                p = input("> ").strip().strip('"')
                if p:
                    cfg["database"] = p
                    continue
            print("\nCollegamento non riuscito:\n  %s" % msg)
            if not èServerLocale(cfg["host"]):
                print("\nControlla che il PC server (%s) sia acceso e raggiungibile, che il firewall lasci passare la porta %s" % (cfg["host"], cfg["port"]))
                print("e che il percorso del .GDB sia quello che vede il server (non una cartella di rete).")
            else:
                print("\nControlla che Levante/Firebird sia attivo su questo PC e che il file .GDB sia quello giusto.")
            print("Per ricominciare da capo cancella il file config_levante.json.")
            sys.exit(1)


def valore(v):
    if v is None:
        return ""
    if isinstance(v, datetime.datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, datetime.date):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, datetime.time):
        return v.strftime("%H:%M:%S")
    if isinstance(v, (decimal.Decimal, float)):
        s = format(v, "f") if isinstance(v, decimal.Decimal) else repr(v)
        return s[:-2] if s.endswith(".0") else s
    if isinstance(v, bytes):
        return v.decode("latin-1", "replace")
    return str(v).replace("\r\n", "\n").replace("\r", "\n").rstrip()


def esporta(con, nome, sql, cartella, cfg):
    if not sql.lstrip().upper().startswith("SELECT"):
        raise RuntimeError("Query non di sola lettura: %s" % nome)
    cur = con.cursor()
    cur.execute(sql)
    colonne = [d[0] for d in cur.description]
    percorso = os.path.join(cartella, nome + ".csv")
    righe = 0
    with open(percorso, "w", newline="", encoding="utf-8-sig" if cfg["bom"] else "utf-8") as f:
        w = csv.writer(f, delimiter=cfg["separatore"], quoting=csv.QUOTE_MINIMAL)
        w.writerow(colonne)
        while True:
            blocco = cur.fetchmany(2000)
            if not blocco:
                break
            for r in blocco:
                w.writerow([valore(x) for x in r])
                righe += 1
    cur.close()
    return righe


def esporta_barre(con, cartella, cfg, cod, descr, um, prezzo, barre):
    """Tutti gli articoli che hanno un codice a barre -> codici_barre.csv (CODICE, BARRE, DESCRIZIONE, UM, PREZZO).
    Serve allo scanner dell'app dei tecnici. Al massimo 100000 righe."""
    sel = "SELECT FIRST 100000 A.%s AS CODICE, A.%s AS BARRE, A.%s AS DESCRIZIONE, %s AS UM, %s AS PREZZO FROM ARTICOLI A WHERE A.%s IS NOT NULL AND TRIM(A.%s) <> '' ORDER BY A.%s" % (
        cod, barre, descr, ("A.%s" % um) if um else "''", ("A.%s" % prezzo) if prezzo else "''", barre, barre, cod)
    try:
        n = esporta(con, "codici_barre", sel, cartella, cfg)
        print("  %-28s %6d righe" % ("codici a barre", n))
    except Exception as e:
        print("  codici a barre              ERRORE: %s" % e)


def esporta_sottocantieri(con, cartella, cfg):
    """Sottocantieri dei cantieri (tabelle SOTTOCANTIERI1, 2, 3) -> sottocantieri1.csv, sottocantieri2.csv, sottocantieri3.csv.
    Le colonne vengono lette dal database (tutte, tranne prezzi, costi e importi, che non escono mai); l'app riconosce da sola
    quale colonna lega il sottocantiere al suo cantiere. sottocantieri_diagnosi.txt elenca le colonne trovate.
    Facoltativo: se una tabella non esiste o la query non riesce, il resto dell'esportazione non ne risente."""
    escluse = ("PRZ", "PREZZ", "COST", "IMPORT", "RICAR", "MARGIN", "SCONT", "TARIFF", "PAGAM")
    diag = []
    for n in (1, 2, 3):
        tab = "SOTTOCANTIERI%d" % n
        cur = con.cursor()
        cur.execute("SELECT TRIM(RF.RDB$FIELD_NAME) FROM RDB$RELATION_FIELDS RF WHERE TRIM(RF.RDB$RELATION_NAME) = '%s' ORDER BY RF.RDB$FIELD_POSITION" % tab)
        colonne = [str(r[0]).strip() for r in cur.fetchall()]
        cur.close()
        if not colonne:
            diag.append("%s: tabella non trovata" % tab)
            continue
        buone = [c for c in colonne if not any(x in c.upper() for x in escluse)]
        diag.append("%s: %s%s" % (tab, ", ".join(buone), ("   [non esportate: " + ", ".join(c for c in colonne if c not in buone) + "]") if len(buone) != len(colonne) else ""))
        if not buone:
            continue
        try:
            r = esporta(con, "sottocantieri%d" % n, "SELECT FIRST 100000 %s FROM %s" % (", ".join('"%s"' % c for c in buone), tab), cartella, cfg)
            print("  %-28s %6d righe" % ("sottocantieri livello %d" % n, r))
        except Exception as e:
            diag.append("%s: ERRORE %s" % (tab, e))
            print("  sottocantieri livello %d     ERRORE: %s" % (n, e))
    with open(os.path.join(cartella, "sottocantieri_diagnosi.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(diag) + "\n")


def esporta_articoli(con, cartella, cfg):
    """Articoli segnati come PREFERITO in Levante -> articoli.csv (CODICE, DESCRIZIONE, UM, PREZZO).
    I nomi delle colonne della tabella ARTICOLI vengono riconosciuti da soli; se qualcosa non torna
    il file articoli_diagnosi.txt elenca le colonne trovate."""
    cur = con.cursor()
    cur.execute("SELECT TRIM(RF.RDB$FIELD_NAME) FROM RDB$RELATION_FIELDS RF WHERE TRIM(RF.RDB$RELATION_NAME) = 'ARTICOLI'")
    colonne = [str(r[0]).strip().upper() for r in cur.fetchall()]
    cur.close()
    diag = os.path.join(cartella, "articoli_diagnosi.txt")
    if not colonne:
        with open(diag, "w", encoding="utf-8") as f:
            f.write("La tabella ARTICOLI non esiste in questo database.\n")
        print("  articoli preferiti          tabella ARTICOLI non trovata (vedi articoli_diagnosi.txt)")
        return

    def scegli(candidati):
        for c in candidati:
            if c in colonne:
                return c
        return None
    cod = scegli(["CODICEARTICOLO", "CODICE", "CODART", "COD", "CODICEARTICOLO"])
    descr = scegli(["DESCRIZIONE", "DESCR", "DESCRIZ", "DESCRIZIONEARTICOLO"])
    um = scegli(["UNITADIMISURA", "UM", "UNITAMISURA", "UNIMIS", "UNITA", "UDM"])
    prezzo = scegli(["PREZZODIVENDITA", "PREZZOVENDITA", "PREZZO_VENDITA", "PREZZOVEND", "PREZZO", "PREZZO1", "PREZZOLISTINO", "LISTINO", "PVENDITA"])
    barre = scegli(["BARCODE", "CODICEBARRE", "CODICE_BARRE", "CODBARRE", "BARRE", "CODICEEAN", "EAN", "EAN13", "CODICEABARRE", "CODICEBARRA", "BARCODE1"])
    if not barre:      # nome non previsto: prima colonna che contiene BARR, BARCODE o EAN
        for c in colonne:
            if "BARR" in c or "BARCODE" in c or c.startswith("EAN"):
                barre = c
                break
    with open(diag, "w", encoding="utf-8") as f:
        f.write("Colonne di ARTICOLI: %s\n" % ", ".join(colonne))
        f.write("Usate: codice=%s descrizione=%s um=%s prezzo=%s preferito=%s codice a barre=%s\n" % (cod, descr, um, prezzo, "PREFERITO" in colonne, barre))
    if cod and descr and barre:
        esporta_barre(con, cartella, cfg, cod, descr, um, prezzo, barre)
    else:
        print("  codici a barre              colonna non trovata in ARTICOLI (vedi articoli_diagnosi.txt)")
    if not (cod and descr and "PREFERITO" in colonne):
        print("  articoli preferiti          colonne non riconosciute (vedi articoli_diagnosi.txt)")
        return
    sel = "SELECT A.%s AS CODICE, A.%s AS DESCRIZIONE, %s AS UM, %s AS PREZZO FROM ARTICOLI A WHERE A.PREFERITO = %%s ORDER BY A.%s" % (
        cod, descr, ("A.%s" % um) if um else "''", ("A.%s" % prezzo) if prezzo else "''", descr)
    ultimo = None
    for valore_vero in ("TRUE", "1", "'T'", "'S'", "'1'"):          # il tipo del campo cambia da versione a versione
        try:
            n = esporta(con, "articoli", sel % valore_vero, cartella, cfg)
        except Exception as e:
            ultimo = e
            continue
        if n:
            print("  %-28s %6d righe" % ("articoli preferiti", n))
            return
    if ultimo:
        print("  articoli preferiti          ERRORE: %s" % ultimo)
    else:
        print("  articoli preferiti                0 righe (nessun articolo con PREFERITO attivo?)")


def esporta_schema(con, radice):
    """Elenco di tutte le tabelle e colonne del database (solo i nomi, nessun dato) in schema_database.txt:
    serve a adattare le query quando una versione di Levante usa nomi di colonna diversi."""
    cur = con.cursor()
    cur.execute("SELECT TRIM(RF.RDB$RELATION_NAME), TRIM(RF.RDB$FIELD_NAME) FROM RDB$RELATION_FIELDS RF "
                "JOIN RDB$RELATIONS R ON R.RDB$RELATION_NAME = RF.RDB$RELATION_NAME "
                "WHERE COALESCE(R.RDB$SYSTEM_FLAG, 0) = 0 AND R.RDB$VIEW_BLR IS NULL "
                "ORDER BY 1, RF.RDB$FIELD_POSITION")
    tab = {}
    for t, c in cur.fetchall():
        tab.setdefault(str(t).strip(), []).append(str(c).strip())
    cur.close()
    os.makedirs(radice, exist_ok=True)
    with open(os.path.join(radice, "schema_database.txt"), "w", encoding="utf-8") as f:
        f.write("Tabelle e colonne del database (solo nomi, nessun dato). %d tabelle.\n\n" % len(tab))
        for t in sorted(tab):
            f.write("%s: %s\n" % (t, ", ".join(tab[t])))
    print("  schema del database         %d tabelle (schema_database.txt)" % len(tab))


def pulisci_vecchie(radice, corrente, tieni=8):
    """Con l'esportazione ogni 15 minuti le cartelle si accumulano: restano le ultime `tieni` (e i relativi zip)."""
    try:
        import shutil
        nomi = sorted(n for n in os.listdir(radice) if re.match(r"^\d{4}-\d{2}-\d{2}_\d{4}$", n) and os.path.isdir(os.path.join(radice, n)))
        for n in nomi[:-tieni]:
            if n == corrente:
                continue
            shutil.rmtree(os.path.join(radice, n), ignore_errors=True)
            z = os.path.join(radice, "Esportazione_" + n + ".zip")
            if os.path.exists(z):
                os.remove(z)
    except Exception:
        pass


def main():
    cfg = CONFIG
    oggi = datetime.date.today()
    date = {
        "{DAL}": (oggi - datetime.timedelta(days=cfg["giorni_indietro"])).isoformat(),
        "{AL}": (oggi + datetime.timedelta(days=cfg["giorni_avanti"])).isoformat(),
        "{STORICO}": (oggi - datetime.timedelta(days=365 * cfg["anni_storico"])).isoformat(),
    }
    cartella = os.path.join(cfg["cartella_output"], datetime.datetime.now().strftime("%Y-%m-%d_%H%M"))
    os.makedirs(cartella, exist_ok=True)

    chiedi_database(cfg)
    print("Mi collego a %s ..." % (cfg["database"] if èServerLocale(cfg["host"]) else "%s:%s" % (cfg["host"], cfg["database"])))
    con = collega(cfg)
    ricordato = leggi_memoria()
    salva_memoria(cfg)
    if ricordato.get("database") != cfg["database"] or ricordato.get("host") != cfg["host"]:
        print("Ho ricordato server e database: la prossima volta basta un doppio clic su Esporta_Levante.bat.")

    try:
        esporta_schema(con, cfg["cartella_output"])
    except Exception as e:
        print("  schema del database         ERRORE: %s" % e)
    esiti, errori = [], 0
    for nome, sql in QUERIES.items():
        for chiave, d in date.items():
            sql = sql.replace(chiave, d)
        try:
            n = esporta(con, nome, sql, cartella, cfg)
            esiti.append((nome, n, "ok"))
            print("  %-28s %6d righe" % (nome, n))
        except Exception as e:
            if nome not in NON_FATALI:      # chiamate e cantieri sono facoltativi: se la query non riesce non deve rovinare il resto
                errori += 1
            esiti.append((nome, 0, "ERRORE: %s" % e))
            print("  %-28s ERRORE: %s" % (nome, e))
    try:
        esporta_articoli(con, cartella, cfg)
    except Exception as e:
        print("  articoli preferiti          ERRORE: %s" % e)
    try:
        esporta_sottocantieri(con, cartella, cfg)
    except Exception as e:
        print("  sottocantieri               ERRORE: %s" % e)
    try:
        esporta_documenti(con, cartella, cfg, date)
    except Exception as e:
        print("  documenti allegati          ERRORE: %s" % e)
    con.close()
    try:
        esporta_modelli(cartella, cfg)
    except Exception as e:
        print("  modelli di stampa            ERRORE: %s" % e)

    with open(os.path.join(cartella, "_riepilogo.txt"), "w", encoding="utf-8") as f:
        f.write("Esportazione del %s\n" % datetime.datetime.now().strftime("%d/%m/%Y %H:%M"))
        f.write("Appuntamenti dal %s al %s - storico dal %s\n\n" % (date["{DAL}"], date["{AL}"], date["{STORICO}"]))
        for nome, n, esito in esiti:
            f.write("%-28s %6d  %s\n" % (nome, n, esito))
    # un unico file .zip con tutto: nell'app basta sceglierlo (Impostazioni > Ufficio > Posta... > "Scegli i file di Levante")
    try:
        nome_zip = os.path.join(cfg["cartella_output"], "Esportazione_" + os.path.basename(cartella) + ".zip")
        with zipfile.ZipFile(nome_zip, "w", zipfile.ZIP_DEFLATED) as z:
            for f in sorted(os.listdir(cartella)):
                pf = os.path.join(cartella, f)
                if os.path.isfile(pf):
                    z.write(pf, f)
        print("  file unico per l'app        %s (%.1f MB)" % (os.path.abspath(nome_zip), os.path.getsize(nome_zip) / 1048576.0))
    except Exception as e:
        print("  file unico per l'app        ERRORE: %s" % e)
    pulisci_vecchie(cfg["cartella_output"], os.path.basename(cartella))
    print("\nFatto. File salvati in: %s" % os.path.abspath(cartella))
    if os.name == "nt" and not os.environ.get("ASSISTENZA_SILENZIOSO"):      # nell'esportazione pianificata non si apre la cartella
        try:
            os.startfile(os.path.abspath(cartella))
        except Exception:
            pass
    if errori:
        print("Attenzione: %d query con errore (vedi sopra)." % errori)
        sys.exit(2)


if __name__ == "__main__":
    main()
